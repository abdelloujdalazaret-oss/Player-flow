# Flutter
-keep class io.flutter.** { *; }
-dontwarn io.flutter.embedding.**

# media_kit / libmpv
-keep class com.alexmercerind.** { *; }
-keep class is.xyz.mpv.** { *; }
-keep class dev.flutter.** { *; }

# Éviter l'échec de R8 sur des classes optionnelles manquantes
-dontwarn **
