import 'package:flutter_test/flutter_test.dart';
import 'package:player_flow/models/channel.dart';
import 'package:player_flow/services/m3u_parser.dart';

void main() {
  group('parseM3u', () {
    test('playlist simple', () {
      const input = '#EXTM3U\n'
          '#EXTINF:-1,Chaîne 1\n'
          'http://example.com/1.ts\n'
          '#EXTINF:-1,Chaîne 2\n'
          'http://example.com/2.ts\n';
      final list = parseM3u(input);
      expect(list.length, 2);
      expect(list[0].name, 'Chaîne 1');
      expect(list[0].url, 'http://example.com/1.ts');
      expect(list[0].group, 'Sans catégorie');
      expect(list[0].type, ContentType.live);
      expect(list[1].name, 'Chaîne 2');
    });

    test('tvg-id, tvg-name, tvg-logo et group-title', () {
      const input = '#EXTM3U\n'
          '#EXTINF:-1 tvg-id="a.fr" tvg-name="Nom TVG" tvg-logo="http://x.com/logo.png" group-title="Sport",Titre affiché\n'
          'http://example.com/a.ts\n';
      final c = parseM3u(input).single;
      expect(c.name, 'Titre affiché');
      expect(c.tvgId, 'a.fr');
      expect(c.logo, 'http://x.com/logo.png');
      expect(c.group, 'Sport');
    });

    test('tvg-name utilisé quand le titre est vide', () {
      const input = '#EXTINF:-1 tvg-name="Seulement TVG" group-title="Info",\n'
          'http://example.com/b.ts\n';
      expect(parseM3u(input).single.name, 'Seulement TVG');
    });

    test('EXTGRP, avec group-title prioritaire', () {
      const input = '#EXTINF:-1,Doc\n'
          '#EXTGRP:Documentaires\n'
          'http://example.com/doc.ts\n'
          '#EXTINF:-1 group-title="Cinéma",Film\n'
          '#EXTGRP:Ignoré\n'
          'http://example.com/film.ts\n';
      final list = parseM3u(input);
      expect(list[0].group, 'Documentaires');
      expect(list[1].group, 'Cinéma');
    });

    test('BOM en début de fichier', () {
      const input = '\uFEFF#EXTM3U\n#EXTINF:-1,Avec BOM\nhttp://example.com/bom.ts\n';
      final list = parseM3u(input);
      expect(list.length, 1);
      expect(list.single.name, 'Avec BOM');
    });

    test('guillemets doubles, simples et virgule dans une valeur', () {
      const input = '#EXTINF:-1 group-title="Films, Séries" tvg-name=\'Nom simple\',Canal\n'
          'http://example.com/q.ts\n';
      final c = parseM3u(input).single;
      expect(c.group, 'Films, Séries');
      expect(c.name, 'Canal');
    });

    test('lignes imparfaites récupérées', () {
      const input = '#EXTM3U\r\n'
          '\r\n'
          '#EXTINF:-1 tvg-name="Sans virgule" group-title="G"\r\n'
          'http://example.com/1.ts   \r\n'
          'ceci n\'est pas une url\r\n'
          '#EXTINF:-1 tvg-name="Cassé,Nom récupéré\r\n'
          'http://example.com/2.ts\r\n'
          'http://example.com/sans-extinf.ts\r\n';
      final list = parseM3u(input);
      expect(list.length, 3);
      expect(list[0].name, 'Sans virgule');
      expect(list[0].group, 'G');
      expect(list[0].url, 'http://example.com/1.ts');
      expect(list[1].name, 'Nom récupéré');
      expect(list[2].name, 'http://example.com/sans-extinf.ts');
    });

    test('User-Agent via EXTVLCOPT, limité à la chaîne suivante', () {
      const input = '#EXTINF:-1,A\n'
          '#EXTVLCOPT:http-user-agent=MonUA/1.0\n'
          'http://example.com/a.ts\n'
          '#EXTINF:-1,B\n'
          'http://example.com/b.ts\n';
      final list = parseM3u(input);
      expect(list[0].userAgent, 'MonUA/1.0');
      expect(list[1].userAgent, isNull);
    });

    test('User-Agent au format Kodi (url|User-Agent=...)', () {
      const input = '#EXTINF:-1,K\nhttp://example.com/k.ts|User-Agent=Foo\n';
      final c = parseM3u(input).single;
      expect(c.url, 'http://example.com/k.ts');
      expect(c.userAgent, 'Foo');
    });

    test('détection films et séries par URL', () {
      const input = '#EXTINF:-1,F\nhttp://h/movie/u/p/1.mp4\n'
          '#EXTINF:-1,S\nhttp://h/series/u/p/2.mkv\n'
          '#EXTINF:-1,L\nhttp://h/live/u/p/3.ts\n';
      final list = parseM3u(input);
      expect(list[0].type, ContentType.movie);
      expect(list[1].type, ContentType.series);
      expect(list[2].type, ContentType.live);
    });
  });
}
