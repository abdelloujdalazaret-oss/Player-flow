import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../core/storage/secure_kv.dart';
import '../models/channel.dart';
import '../models/subscription.dart';

class SubscriptionStore extends ChangeNotifier {
  static const _kSubs = 'subscriptions';
  static const _kActive = 'active_subscription';
  static const _kFavorites = 'favorites';
  static const _kRecents = 'recents';
  static const _maxRecents = 40;

  final SecureKv _secure = const SecureKv();
  SharedPreferences? _prefs;

  List<Subscription> _subscriptions = [];
  String? _activeId;
  List<Channel> _favorites = [];
  List<Channel> _recents = [];

  List<Subscription> get subscriptions => List.unmodifiable(_subscriptions);
  List<Channel> get favorites => List.unmodifiable(_favorites);
  List<Channel> get recents => List.unmodifiable(_recents);
  String? get activeId => _activeId;

  Subscription? get active {
    for (final s in _subscriptions) {
      if (s.id == _activeId) return s;
    }
    return null;
  }

  Future<void> load() async {
    final prefs = _prefs = await SharedPreferences.getInstance();

    final raw = prefs.getString(_kSubs);
    if (raw != null) {
      try {
        for (final item in jsonDecode(raw) as List) {
          final pub = Map<String, dynamic>.from(item as Map);
          final secretRaw = await _secure.read('sub_${pub['id']}');
          final secret = secretRaw == null
              ? <String, dynamic>{}
              : Map<String, dynamic>.from(jsonDecode(secretRaw) as Map);
          _subscriptions.add(Subscription.fromJson(pub, secret));
        }
      } catch (_) {
        _subscriptions = [];
      }
    }
    _activeId = prefs.getString(_kActive);
    if (active == null && _subscriptions.isNotEmpty) {
      _activeId = _subscriptions.first.id;
    }
    _favorites = _readChannels(prefs.getString(_kFavorites));
    _recents = _readChannels(prefs.getString(_kRecents));
  }

  List<Channel> _readChannels(String? raw) {
    if (raw == null) return [];
    try {
      return [
        for (final item in jsonDecode(raw) as List)
          Channel.fromJson(Map<String, dynamic>.from(item as Map)),
      ];
    } catch (_) {
      return [];
    }
  }

  Future<void> _persistSubscriptions() async {
    final prefs = _prefs ??= await SharedPreferences.getInstance();
    await prefs.setString(_kSubs, jsonEncode([for (final s in _subscriptions) s.toPublicJson()]));
    await prefs.setString(_kActive, _activeId ?? '');
  }

  Future<void> save(Subscription s) async {
    final i = _subscriptions.indexWhere((x) => x.id == s.id);
    if (i >= 0) {
      _subscriptions[i] = s;
    } else {
      _subscriptions.add(s);
    }
    _activeId ??= s.id;
    await _secure.write('sub_${s.id}', jsonEncode(s.toSecretJson()));
    await _persistSubscriptions();
    notifyListeners();
  }

  Future<void> remove(String id) async {
    _subscriptions.removeWhere((s) => s.id == id);
    await _secure.delete('sub_$id');
    if (_activeId == id) {
      _activeId = _subscriptions.isEmpty ? null : _subscriptions.first.id;
    }
    await _persistSubscriptions();
    notifyListeners();
  }

  Future<void> setActive(String id) async {
    _activeId = id;
    await _persistSubscriptions();
    notifyListeners();
  }

  Future<void> updateStatus(String id, String status) async {
    final i = _subscriptions.indexWhere((s) => s.id == id);
    if (i < 0 || _subscriptions[i].status == status) return;
    _subscriptions[i] = _subscriptions[i].copyWith(status: status);
    await _persistSubscriptions();
    notifyListeners();
  }

  bool isFavorite(Channel c) => _favorites.any((f) => f.key == c.key);

  Future<void> toggleFavorite(Channel c) async {
    if (isFavorite(c)) {
      _favorites.removeWhere((f) => f.key == c.key);
    } else {
      _favorites.insert(0, c);
    }
    await _writeChannels(_kFavorites, _favorites);
    notifyListeners();
  }

  Future<void> addRecent(Channel c) async {
    _recents.removeWhere((r) => r.key == c.key);
    _recents.insert(0, c);
    if (_recents.length > _maxRecents) {
      _recents = _recents.sublist(0, _maxRecents);
    }
    await _writeChannels(_kRecents, _recents);
    notifyListeners();
  }

  Future<void> _writeChannels(String key, List<Channel> list) async {
    final prefs = _prefs ??= await SharedPreferences.getInstance();
    await prefs.setString(key, jsonEncode([for (final c in list) c.toJson()]));
  }
}
