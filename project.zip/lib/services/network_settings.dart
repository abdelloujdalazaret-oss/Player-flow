import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:http/io_client.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../app/constants.dart';
import '../core/network/doh_resolver.dart';

enum DnsMode { off, cloudflare, google, quad9, custom }

enum ProxyType { http, https, socks }

class DiagnosticStep {
  const DiagnosticStep(this.label, this.ok, this.detail);

  final String label;
  final bool ok;
  final String detail;
}

class NetworkSettings extends ChangeNotifier {
  DnsMode dnsMode = DnsMode.off;
  String customDoh = '';
  bool proxyEnabled = false;
  ProxyType proxyType = ProxyType.http;
  String proxyHost = '';
  int proxyPort = 8080;
  String userAgent = AppConstants.defaultUserAgent;

  /// En-têtes personnalisés, au format « Nom: valeur ».
  List<String> customHeaders = [];
  int connectTimeoutSec = 15;
  int receiveTimeoutSec = 30;

  SharedPreferences? _prefs;

  Duration get connectTimeout => Duration(seconds: connectTimeoutSec);
  Duration get receiveTimeout => Duration(seconds: receiveTimeoutSec);

  Future<void> load() async {
    final p = _prefs = await SharedPreferences.getInstance();
    dnsMode = DnsMode.values.firstWhere(
      (m) => m.name == p.getString('net_dns'),
      orElse: () => DnsMode.off,
    );
    customDoh = p.getString('net_doh_custom') ?? '';
    proxyEnabled = p.getBool('net_proxy_enabled') ?? false;
    proxyType = ProxyType.values.firstWhere(
      (m) => m.name == p.getString('net_proxy_type'),
      orElse: () => ProxyType.http,
    );
    proxyHost = p.getString('net_proxy_host') ?? '';
    proxyPort = p.getInt('net_proxy_port') ?? 8080;
    userAgent = p.getString('net_user_agent') ?? AppConstants.defaultUserAgent;
    customHeaders = p.getStringList('net_headers') ?? [];
    connectTimeoutSec = p.getInt('net_connect_timeout') ?? 15;
    receiveTimeoutSec = p.getInt('net_receive_timeout') ?? 30;
  }

  Future<void> update(void Function() change) async {
    change();
    notifyListeners();
    final p = _prefs ??= await SharedPreferences.getInstance();
    await p.setString('net_dns', dnsMode.name);
    await p.setString('net_doh_custom', customDoh);
    await p.setBool('net_proxy_enabled', proxyEnabled);
    await p.setString('net_proxy_type', proxyType.name);
    await p.setString('net_proxy_host', proxyHost);
    await p.setInt('net_proxy_port', proxyPort);
    await p.setString('net_user_agent', userAgent);
    await p.setStringList('net_headers', customHeaders);
    await p.setInt('net_connect_timeout', connectTimeoutSec);
    await p.setInt('net_receive_timeout', receiveTimeoutSec);
  }

  String? get dohEndpoint {
    switch (dnsMode) {
      case DnsMode.off:
        return null;
      case DnsMode.cloudflare:
        return 'https://cloudflare-dns.com/dns-query';
      case DnsMode.google:
        return 'https://dns.google/resolve';
      case DnsMode.quad9:
        return 'https://dns.quad9.net:5053/dns-query';
      case DnsMode.custom:
        final u = customDoh.trim();
        return u.startsWith('https://') ? u : null;
    }
  }

  bool get _proxyActive =>
      proxyEnabled && proxyHost.trim().isNotEmpty && proxyType != ProxyType.socks;

  /// En-têtes envoyés avec chaque requête (User-Agent + en-têtes personnalisés).
  Map<String, String> get requestHeaders {
    final headers = <String, String>{'User-Agent': userAgent};
    for (final line in customHeaders) {
      final i = line.indexOf(':');
      if (i > 0) {
        final k = line.substring(0, i).trim();
        final v = line.substring(i + 1).trim();
        if (k.isNotEmpty) headers[k] = v;
      }
    }
    return headers;
  }

  http.Client createClient() {
    final inner = HttpClient()
      ..connectionTimeout = connectTimeout
      ..userAgent = userAgent;
    if (_proxyActive) {
      final target = '${proxyHost.trim()}:$proxyPort';
      inner.findProxy = (_) => 'PROXY $target';
    }
    final endpoint = dohEndpoint;
    if (endpoint != null && !_proxyActive) {
      final resolver = DohResolver(endpoint);
      inner.connectionFactory = (Uri url, String? proxyH, int? proxyP) async {
        final host = proxyH ?? url.host;
        final port = proxyP ?? url.port;
        final ip = proxyH == null ? await resolver.resolve(host) : null;
        // Repli automatique sur le DNS système si la résolution DoH échoue.
        return Socket.startConnect(ip ?? host, port);
      };
    }
    return IOClient(inner);
  }

  Future<List<DiagnosticStep>> diagnose(String address) async {
    var text = address.trim();
    if (!text.contains('://')) text = 'http://$text';
    final uri = Uri.tryParse(text);
    if (uri == null || uri.host.isEmpty) {
      return const [DiagnosticStep('Adresse', false, 'Adresse invalide.')];
    }
    final steps = <DiagnosticStep>[];
    String? ip;

    try {
      final r = await InternetAddress.lookup(uri.host).timeout(connectTimeout);
      ip = r.isNotEmpty ? r.first.address : null;
      steps.add(DiagnosticStep('DNS système', ip != null, ip != null ? 'Adresse trouvée : $ip' : 'Aucune adresse trouvée.'));
    } catch (_) {
      steps.add(const DiagnosticStep('DNS système', false, 'Le nom du serveur ne peut pas être résolu.'));
    }

    final endpoint = dohEndpoint;
    if (endpoint != null) {
      final dohIp = await DohResolver(endpoint).resolve(uri.host);
      steps.add(DiagnosticStep(
        'DNS sécurisé (DoH)',
        dohIp != null,
        dohIp != null ? 'Adresse trouvée : $dohIp' : 'Résolution DoH impossible.',
      ));
      ip ??= dohIp;
    }

    if (ip == null) {
      steps.add(const DiagnosticStep('TCP', false, 'Test ignoré : aucune adresse IP disponible.'));
    } else {
      try {
        final s = await Socket.connect(ip, uri.port, timeout: connectTimeout);
        s.destroy();
        steps.add(DiagnosticStep('TCP', true, 'Connexion établie sur le port ${uri.port}.'));
      } catch (_) {
        steps.add(DiagnosticStep('TCP', false, 'Connexion impossible sur le port ${uri.port}.'));
      }
    }

    final client = createClient();
    try {
      final res = await client.head(uri, headers: requestHeaders).timeout(receiveTimeout);
      steps.add(DiagnosticStep('HTTP', true, 'Le serveur a répondu (code ${res.statusCode}).'));
    } catch (_) {
      steps.add(const DiagnosticStep('HTTP', false, 'Aucune réponse HTTP du serveur.'));
    } finally {
      client.close();
    }
    return steps;
  }
}
