import 'dart:convert';
import 'dart:typed_data';

import '../core/parsers/attribute_parser.dart';
import '../models/channel.dart';

final RegExp _urlRe = RegExp(r'^[a-zA-Z][a-zA-Z0-9+.\-]*://');

ContentType detectContentType(String url) {
  final lower = url.toLowerCase();
  if (lower.contains('/movie/')) return ContentType.movie;
  if (lower.contains('/series/')) return ContentType.series;
  return ContentType.live;
}

String? _nonEmpty(String? value) {
  if (value == null) return null;
  final v = value.trim();
  return v.isEmpty ? null : v;
}

/// Décode des octets (UTF-8 tolérant) puis analyse la playlist.
/// Fonction de premier niveau : utilisable avec `compute`.
List<Channel> parseM3uBytes(Uint8List bytes) {
  return parseM3u(utf8.decode(bytes, allowMalformed: true));
}

/// Analyse tolérante d'une playlist M3U / M3U8.
List<Channel> parseM3u(String input) {
  var text = input;
  if (text.startsWith('\uFEFF')) text = text.substring(1);

  final channels = <Channel>[];
  Map<String, String> attrs = const {};
  String title = '';
  String? extGrp;
  String? vlcUserAgent;

  void reset() {
    attrs = const {};
    title = '';
    extGrp = null;
    vlcUserAgent = null;
  }

  for (final raw in const LineSplitter().convert(text)) {
    final line = raw.trim();
    if (line.isEmpty) continue;

    if (line.startsWith('#')) {
      final upper = line.toUpperCase();
      if (upper.startsWith('#EXTINF')) {
        final colon = line.indexOf(':');
        final body = colon >= 0 ? line.substring(colon + 1) : '';
        final parts = splitExtinf(body);
        attrs = parseExtinfAttributes(parts.header);
        title = parts.title;
      } else if (upper.startsWith('#EXTGRP:')) {
        extGrp = _nonEmpty(line.substring(8));
      } else if (upper.startsWith('#EXTVLCOPT:')) {
        final option = line.substring(11);
        final eq = option.indexOf('=');
        if (eq > 0 && option.substring(0, eq).trim().toLowerCase() == 'http-user-agent') {
          vlcUserAgent = _nonEmpty(option.substring(eq + 1).replaceAll('"', ''));
        }
      }
      continue;
    }

    // Ligne d'URL, éventuellement au format Kodi : url|User-Agent=...
    var url = line;
    String? pipeUserAgent;
    final pipe = line.indexOf('|');
    if (pipe > 0) {
      url = line.substring(0, pipe).trim();
      for (final part in line.substring(pipe + 1).split('&')) {
        final eq = part.indexOf('=');
        if (eq > 0 && part.substring(0, eq).trim().toLowerCase() == 'user-agent') {
          pipeUserAgent = _nonEmpty(Uri.decodeComponent(part.substring(eq + 1)));
        }
      }
    }
    if (!_urlRe.hasMatch(url)) continue;

    var name = title.trim();
    if (name.isEmpty) name = attrs['tvg-name'] ?? '';
    if (name.isEmpty) name = url;

    channels.add(Channel(
      name: name,
      url: url,
      group: _nonEmpty(attrs['group-title']) ?? extGrp ?? 'Sans catégorie',
      type: detectContentType(url),
      logo: _nonEmpty(attrs['tvg-logo']),
      tvgId: _nonEmpty(attrs['tvg-id']),
      userAgent: pipeUserAgent ?? vlcUserAgent,
    ));
    reset();
  }
  return channels;
}
