import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';

import '../models/channel.dart';

/// Cache disque des catalogues : une ouverture suivante est instantanée,
/// la mise à jour se fait ensuite en arrière-plan.
class CatalogCache {
  const CatalogCache();

  Future<File> _file(String subId, ContentType type) async {
    final dir = await getApplicationSupportDirectory();
    final folder = Directory('${dir.path}/catalog');
    if (!await folder.exists()) await folder.create(recursive: true);
    return File('${folder.path}/${subId}_${type.name}.json');
  }

  /// Retourne la liste en cache (ou null) et son ancienneté.
  Future<(List<Channel>, Duration)?> read(String subId, ContentType type) async {
    try {
      final f = await _file(subId, type);
      if (!await f.exists()) return null;
      final raw = await f.readAsString();
      final list = await compute(_decode, raw);
      if (list.isEmpty) return null;
      final age = DateTime.now().difference(await f.lastModified());
      return (list, age);
    } catch (_) {
      return null;
    }
  }

  Future<void> write(String subId, ContentType type, List<Channel> list) async {
    if (list.isEmpty) return;
    try {
      final f = await _file(subId, type);
      final raw = await compute(_encode, list);
      final tmp = File('${f.path}.tmp');
      await tmp.writeAsString(raw, flush: true);
      await tmp.rename(f.path);
    } catch (_) {}
  }

  Future<void> clear(String subId) async {
    try {
      for (final t in ContentType.values) {
        final f = await _file(subId, t);
        if (await f.exists()) await f.delete();
      }
    } catch (_) {}
  }
}

String _encode(List<Channel> list) => jsonEncode([for (final c in list) c.toJson()]);

List<Channel> _decode(String raw) {
  final data = jsonDecode(raw);
  if (data is! List) return const [];
  return [
    for (final item in data)
      if (item is Map) Channel.fromJson(Map<String, dynamic>.from(item)),
  ];
}
