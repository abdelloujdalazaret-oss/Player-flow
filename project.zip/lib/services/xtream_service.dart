import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

import '../core/utils/error_text.dart';
import '../models/channel.dart';

class XtreamService {
  XtreamService({
    required this.server,
    required this.username,
    required this.password,
    required this.client,
    required this.headers,
    required this.timeout,
  });

  final String server;
  final String username;
  final String password;
  final http.Client client;
  final Map<String, String> headers;
  final Duration timeout;

  String get base {
    var s = server.trim();
    if (!s.contains('://')) s = 'http://$s';
    s = s.replaceFirst(RegExp(r'/player_api\.php.*$'), '');
    return s.replaceAll(RegExp(r'/+$'), '');
  }

  Uri _api([Map<String, String> extra = const {}]) {
    return Uri.parse('$base/player_api.php').replace(queryParameters: {
      'username': username,
      'password': password,
      ...extra,
    });
  }

  Future<Uint8List> _get(Uri uri, [Duration? limit]) async {
    final res = await client.get(uri, headers: headers).timeout(limit ?? timeout);
    if (res.statusCode != 200) {
      throw AppException('Le serveur a répondu avec le code ${res.statusCode}.');
    }
    return res.bodyBytes;
  }

  /// Téléchargement des très grandes listes (100 000+ films) : le délai s'applique
  /// à l'inactivité entre deux paquets, et non à la durée totale du téléchargement.
  Future<Uint8List> _getLarge(Uri uri) async {
    final req = http.Request('GET', uri)..headers.addAll(headers);
    final res = await client.send(req).timeout(timeout);
    if (res.statusCode != 200) {
      throw AppException('Le serveur a répondu avec le code ${res.statusCode}.');
    }
    final builder = BytesBuilder(copy: false);
    await for (final chunk in res.stream.timeout(timeout)) {
      builder.add(chunk);
    }
    return builder.takeBytes();
  }

  /// Vérifie l'identifiant, le mot de passe et le statut du compte.
  Future<void> authenticate() async {
    final bytes = await _get(_api());
    final data = await compute(_decodeMap, bytes);
    final info = data['user_info'];
    if (info is! Map) {
      throw const AppException('Réponse inattendue : ce serveur ne semble pas être un serveur Xtream Codes.');
    }
    if (info['auth'].toString() != '1') {
      throw const AppException('Identifiant ou mot de passe incorrect.');
    }
    final status = info['status']?.toString();
    if (status != null && status.isNotEmpty && status.toLowerCase() != 'active') {
      throw AppException("L'abonnement n'est pas actif (statut : $status).");
    }
  }

  /// Charge une section (direct, films ou séries). Les requêtes sont envoyées
  /// l'une après l'autre : beaucoup de serveurs refusent les requêtes parallèles.
  /// Si la liste complète échoue ou revient vide (cas fréquent avec 100 000+ films),
  /// on charge catégorie par catégorie, comme les lecteurs IPTV classiques.
  Future<List<Channel>> loadSection(ContentType type) async {
    final (cats, list) = switch (type) {
      ContentType.live => ('get_live_categories', 'get_live_streams'),
      ContentType.movie => ('get_vod_categories', 'get_vod_streams'),
      ContentType.series => ('get_series_categories', 'get_series'),
    };
    Uint8List catBytes;
    try {
      catBytes = await _get(_api({'action': cats}));
    } catch (_) {
      catBytes = Uint8List.fromList(utf8.encode('[]'));
    }

    Object? lastError;
    for (var attempt = 0; attempt < 2; attempt++) {
      try {
        final listBytes = await _getLarge(_api({'action': list}));
        final result = await compute(_buildChannels, <String, dynamic>{
          'cats': catBytes,
          'list': listBytes,
          'type': type.index,
          'base': base,
          'user': username,
          'pass': password,
        });
        if (result.isNotEmpty) return result;
        lastError = const AppException('Le serveur a renvoyé une liste vide.');
      } catch (e) {
        lastError = e;
      }
      await Future<void>.delayed(const Duration(seconds: 1));
    }

    // Repli : une requête par catégorie.
    final ids = await compute(_categoryIds, catBytes);
    if (ids.isEmpty) throw lastError ?? const AppException('Aucune catégorie trouvée.');
    final out = <Channel>[];
    var failures = 0;
    for (final id in ids) {
      try {
        final bytes = await _getLarge(_api({'action': list, 'category_id': id}));
        out.addAll(await compute(_buildChannels, <String, dynamic>{
          'cats': catBytes,
          'list': bytes,
          'type': type.index,
          'base': base,
          'user': username,
          'pass': password,
        }));
      } catch (e) {
        failures++;
        lastError = e;
        if (failures >= 5 && out.isEmpty) break;
      }
    }
    if (out.isEmpty) throw lastError ?? const AppException('Aucun contenu trouvé.');
    return out;
  }

  Future<List<Channel>> loadAll() async {
    final all = <Channel>[];
    for (final type in ContentType.values) {
      all.addAll(await loadSection(type));
    }
    return all;
  }

  Future<List<Channel>> loadEpisodes(Channel series) async {
    final bytes = await _get(_api({'action': 'get_series_info', 'series_id': series.seriesId ?? ''}));
    final data = await compute(_decodeMap, bytes);
    final episodes = data['episodes'];
    final out = <Channel>[];

    void add(String season, dynamic e) {
      if (e is! Map) return;
      final id = e['id']?.toString();
      if (id == null) return;
      final ext = (e['container_extension'] ?? 'mp4').toString();
      final epNum = (e['episode_num'] ?? '').toString();
      final title = (e['title'] ?? '').toString();
      final label = 'S$season E$epNum${title.isEmpty ? '' : ' – $title'}';
      final info = e['info'];
      final image = info is Map ? info['movie_image']?.toString() : null;
      out.add(Channel(
        name: label,
        url: '$base/series/$username/$password/$id.$ext',
        group: series.name,
        type: ContentType.series,
        logo: (image != null && image.isNotEmpty) ? image : series.logo,
      ));
    }

    if (episodes is Map) {
      episodes.forEach((season, list) {
        if (list is List) {
          for (final e in list) {
            add(season.toString(), e);
          }
        }
      });
    } else if (episodes is List) {
      for (var i = 0; i < episodes.length; i++) {
        final list = episodes[i];
        if (list is List) {
          for (final e in list) {
            add('${i + 1}', e);
          }
        }
      }
    }
    return out;
  }
}

List<String> _categoryIds(Uint8List bytes) {
  return [
    for (final c in _decodeList(bytes))
      if (c is Map && c['category_id'] != null) c['category_id'].toString(),
  ];
}

Map<String, dynamic> _decodeMap(Uint8List bytes) {
  final v = jsonDecode(utf8.decode(bytes, allowMalformed: true));
  return v is Map ? Map<String, dynamic>.from(v) : <String, dynamic>{};
}

List<dynamic> _decodeList(Uint8List bytes) {
  final v = jsonDecode(utf8.decode(bytes, allowMalformed: true));
  return v is List ? v : <dynamic>[];
}

List<Channel> _buildChannels(Map<String, dynamic> a) {
  final categories = <String, String>{};
  for (final c in _decodeList(a['cats'] as Uint8List)) {
    if (c is Map) {
      categories[c['category_id'].toString()] = (c['category_name'] ?? '').toString();
    }
  }
  final type = ContentType.values[a['type'] as int];
  final base = a['base'] as String;
  final user = a['user'] as String;
  final pass = a['pass'] as String;

  final out = <Channel>[];
  for (final s in _decodeList(a['list'] as Uint8List)) {
    if (s is! Map) continue;
    final name = (s['name'] ?? s['title'] ?? '').toString();
    if (name.isEmpty) continue;
    final group = categories[s['category_id']?.toString()] ?? 'Sans catégorie';
    String? logo(Object? v) {
      final t = v?.toString() ?? '';
      return t.isEmpty ? null : t;
    }

    switch (type) {
      case ContentType.live:
        out.add(Channel(
          name: name,
          url: '$base/live/$user/$pass/${s['stream_id']}.ts',
          group: group,
          type: type,
          logo: logo(s['stream_icon']),
          tvgId: logo(s['epg_channel_id']),
        ));
      case ContentType.movie:
        final ext = (s['container_extension'] ?? 'mp4').toString();
        out.add(Channel(
          name: name,
          url: '$base/movie/$user/$pass/${s['stream_id']}.$ext',
          group: group,
          type: type,
          logo: logo(s['stream_icon']),
        ));
      case ContentType.series:
        out.add(Channel(
          name: name,
          url: '',
          group: group,
          type: type,
          logo: logo(s['cover']),
          seriesId: s['series_id']?.toString(),
        ));
    }
  }
  return out;
}
