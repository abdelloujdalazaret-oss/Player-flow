import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

import '../core/utils/error_text.dart';
import '../models/channel.dart';
import '../models/subscription.dart';
import 'm3u_parser.dart';
import 'network_settings.dart';
import 'xtream_service.dart';

/// Point d'entrée unique pour charger ou tester un abonnement.
class PlaylistService {
  PlaylistService(this.net);

  final NetworkSettings net;

  XtreamService _xtream(Subscription s, http.Client client) => XtreamService(
        server: s.url,
        username: s.username,
        password: s.password,
        client: client,
        headers: net.requestHeaders,
        timeout: net.receiveTimeout,
      );

  Future<List<Channel>> load(Subscription s) async {
    final client = net.createClient();
    try {
      if (s.type == SubscriptionType.xtream) {
        return await _xtream(s, client).loadAll();
      }
      final res = await client
          .get(Uri.parse(s.url.trim()), headers: net.requestHeaders)
          .timeout(net.receiveTimeout);
      if (res.statusCode != 200) {
        throw AppException('Le serveur a répondu avec le code ${res.statusCode}.');
      }
      final channels = await compute(parseM3uBytes, res.bodyBytes);
      if (channels.isEmpty) {
        throw const AppException('Aucune chaîne trouvée dans cette playlist.');
      }
      return channels;
    } finally {
      client.close();
    }
  }

  Future<List<Channel>> loadSection(Subscription s, ContentType type) async {
    final client = net.createClient();
    try {
      return await _xtream(s, client).loadSection(type);
    } finally {
      client.close();
    }
  }

  Future<List<Channel>> episodes(Subscription s, Channel series) async {
    final client = net.createClient();
    try {
      return await _xtream(s, client).loadEpisodes(series);
    } finally {
      client.close();
    }
  }

  /// Teste la connexion. Lève une exception en cas d'échec.
  Future<String> test(Subscription s) async {
    final client = net.createClient();
    try {
      if (s.type == SubscriptionType.xtream) {
        await _xtream(s, client).authenticate();
        return 'Connexion réussie : identifiants valides.';
      }
      final uri = Uri.tryParse(s.url.trim());
      if (uri == null || !uri.hasScheme || uri.host.isEmpty) {
        throw const AppException("L'URL de la playlist est invalide.");
      }
      final req = http.Request('GET', uri)..headers.addAll(net.requestHeaders);
      final res = await client.send(req).timeout(net.receiveTimeout);
      if (res.statusCode != 200) {
        throw AppException('Le serveur a répondu avec le code ${res.statusCode}.');
      }
      final first = await res.stream.first.timeout(net.receiveTimeout);
      final head = String.fromCharCodes(Uint8List.fromList(first.take(2048).toList()));
      if (!head.contains('#EXTM3U') && !head.contains('#EXTINF')) {
        throw const AppException("Ce lien ne semble pas contenir une playlist M3U valide.");
      }
      return 'Connexion réussie : playlist détectée.';
    } finally {
      client.close();
    }
  }
}
