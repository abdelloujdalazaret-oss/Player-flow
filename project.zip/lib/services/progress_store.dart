import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

/// Mémorise la dernière position de lecture des films et épisodes.
class ProgressStore {
  ProgressStore._();
  static final ProgressStore instance = ProgressStore._();

  static const _key = 'playback_progress';
  static const _maxEntries = 300;

  Map<String, dynamic>? _data;
  SharedPreferences? _prefs;

  Future<Map<String, dynamic>> _load() async {
    if (_data != null) return _data!;
    _prefs = await SharedPreferences.getInstance();
    try {
      final raw = _prefs!.getString(_key);
      _data = raw == null ? <String, dynamic>{} : Map<String, dynamic>.from(jsonDecode(raw) as Map);
    } catch (_) {
      _data = <String, dynamic>{};
    }
    return _data!;
  }

  /// Position à reprendre, ou null si le début est préférable.
  Future<Duration?> resumeFor(String key) async {
    final data = await _load();
    final e = data[key];
    if (e is! Map) return null;
    final pos = (e['p'] as num?)?.toInt() ?? 0;
    final dur = (e['d'] as num?)?.toInt() ?? 0;
    if (pos < 10000) return null;
    if (dur > 0 && pos > dur * 0.95) return null;
    return Duration(milliseconds: pos);
  }

  Future<void> save(String key, Duration position, Duration duration) async {
    final data = await _load();
    if (position.inMilliseconds < 10000) return;
    data[key] = {
      'p': position.inMilliseconds,
      'd': duration.inMilliseconds,
      't': DateTime.now().millisecondsSinceEpoch,
    };
    if (data.length > _maxEntries) {
      final entries = data.entries.toList()
        ..sort((a, b) => ((a.value as Map)['t'] as int).compareTo((b.value as Map)['t'] as int));
      for (final e in entries.take(data.length - _maxEntries)) {
        data.remove(e.key);
      }
    }
    await _prefs?.setString(_key, jsonEncode(data));
  }
}
