import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:media_kit/media_kit.dart';
import 'package:provider/provider.dart';

import 'app/constants.dart';
import 'app/routes.dart';
import 'app/theme.dart';
import 'features/channels/channels_controller.dart';
import 'services/network_settings.dart';
import 'services/subscription_store.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  MediaKit.ensureInitialized();
  final store = SubscriptionStore();
  final net = NetworkSettings();
  await Future.wait([store.load(), net.load()]);
  runApp(PlayerFlowApp(store: store, net: net));
}

class PlayerFlowApp extends StatelessWidget {
  const PlayerFlowApp({super.key, required this.store, required this.net});

  final SubscriptionStore store;
  final NetworkSettings net;

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider<SubscriptionStore>.value(value: store),
        ChangeNotifierProvider<NetworkSettings>.value(value: net),
        ChangeNotifierProvider<ChannelsController>(create: (_) => ChannelsController()),
      ],
      child: MaterialApp(
        title: AppConstants.appName,
        debugShowCheckedModeBanner: false,
        theme: buildTheme(),
        themeMode: ThemeMode.dark,
        darkTheme: buildTheme(),
        locale: const Locale('fr'),
        supportedLocales: const [Locale('fr')],
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        initialRoute: AppRoutes.intro,
        onGenerateRoute: AppRoutes.onGenerate,
      ),
    );
  }
}
