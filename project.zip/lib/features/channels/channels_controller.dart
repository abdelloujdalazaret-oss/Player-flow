import 'dart:async';

import 'package:flutter/foundation.dart';

import '../../core/utils/error_text.dart';
import '../../models/category.dart';
import '../../models/channel.dart';
import '../../models/subscription.dart';
import '../../services/catalog_cache.dart';
import '../../services/network_settings.dart';
import '../../services/playlist_service.dart';
import '../../services/subscription_store.dart';

class ChannelsController extends ChangeNotifier {
  Map<ContentType, List<Channel>> _byType = {for (final t in ContentType.values) t: <Channel>[]};
  final Map<ContentType, List<ChannelCategory>> _categoryCache = {};
  bool loading = false;
  String? error;
  int version = 0;
  int _token = 0;
  bool _disposed = false;

  List<Channel> channelsOf(ContentType type) => _byType[type] ?? const [];

  List<ChannelCategory> categoriesOf(ContentType type) {
    return _categoryCache.putIfAbsent(type, () {
      final counts = <String, int>{};
      for (final c in channelsOf(type)) {
        counts[c.group] = (counts[c.group] ?? 0) + 1;
      }
      final names = counts.keys.toList()..sort((a, b) => a.toLowerCase().compareTo(b.toLowerCase()));
      return [for (final n in names) ChannelCategory(name: n, count: counts[n]!)];
    });
  }

  final Set<ContentType> _pending = {};
  final Map<ContentType, String> _sectionErrors = {};

  bool isPending(ContentType type) => _pending.contains(type);
  String? sectionError(ContentType type) => _sectionErrors[type];

  final CatalogCache _cache = const CatalogCache();
  static const Duration _maxAge = Duration(minutes: 30);

  /// Affiche d'abord le cache (instantané), puis actualise en arrière-plan.
  /// [force] ignore la fraîcheur du cache (bouton Actualiser).
  Future<void> load(Subscription sub, NetworkSettings net, SubscriptionStore store, {bool force = false}) async {
    final token = ++_token;
    loading = true;
    error = null;
    _byType = {for (final t in ContentType.values) t: <Channel>[]};
    _categoryCache.clear();
    _sectionErrors.clear();
    _pending.clear();
    version++;
    notifyListeners();

    // 1) Cache disque.
    final cached = await Future.wait([for (final t in ContentType.values) _cache.read(sub.id, t)]);
    if (token != _token) return;
    var allFresh = true;
    final hasCache = <ContentType>{};
    for (var i = 0; i < ContentType.values.length; i++) {
      final type = ContentType.values[i];
      final entry = cached[i];
      if (entry == null) {
        allFresh = false;
        continue;
      }
      hasCache.add(type);
      _byType[type] = entry.$1;
      if (entry.$2 > _maxAge) allFresh = false;
    }
    if (hasCache.contains(ContentType.live)) {
      loading = false;
      version++;
      notifyListeners();
    }
    if (!force && allFresh) {
      loading = false;
      version++;
      notifyListeners();
      return;
    }

    // 2) Mise à jour réseau en arrière-plan.
    final service = PlaylistService(net);
    var status = 'Valide';
    try {
      if (sub.type == SubscriptionType.xtream) {
        _pending.addAll(ContentType.values);
        version++;
        notifyListeners();
        for (final type in ContentType.values) {
          try {
            final list = await service.loadSection(sub, type);
            if (token != _token) return;
            if (list.isEmpty) throw const AppException('Aucun contenu reçu de ce serveur.');
            _byType[type] = list;
            _categoryCache.remove(type);
            unawaited(_cache.write(sub.id, type, list));
          } catch (e) {
            if (token != _token) return;
            if (!hasCache.contains(type)) {
              if (type == ContentType.live) rethrow;
              _sectionErrors[type] = frenchError(e);
            }
          }
          _pending.remove(type);
          if (type == ContentType.live) loading = false;
          version++;
          notifyListeners();
        }
      } else {
        final all = await service.load(sub);
        if (token != _token) return;
        final map = {for (final t in ContentType.values) t: <Channel>[]};
        for (final c in all) {
          map[c.type]!.add(c);
        }
        _byType = map;
        _categoryCache.clear();
        for (final t in ContentType.values) {
          unawaited(_cache.write(sub.id, t, map[t]!));
        }
        loading = false;
        version++;
        notifyListeners();
      }
    } catch (e) {
      if (token != _token) return;
      if (hasCache.contains(ContentType.live)) {
        // Le cache reste affiché ; l'échec de mise à jour n'est pas bloquant.
        status = 'Valide';
      } else {
        error = frenchError(e);
        status = 'Erreur';
      }
      _pending.clear();
      loading = false;
      version++;
      notifyListeners();
    }
    await store.updateStatus(sub.id, status);
  }

  @override
  void notifyListeners() {
    if (!_disposed) super.notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    super.dispose();
  }
}
