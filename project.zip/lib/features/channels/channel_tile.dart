import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../models/channel.dart';

class ChannelTile extends StatelessWidget {
  const ChannelTile({
    super.key,
    required this.channel,
    required this.isFavorite,
    required this.onTap,
    required this.onToggleFavorite,
  });

  final Channel channel;
  final bool isFavorite;
  final VoidCallback onTap;
  final VoidCallback onToggleFavorite;

  IconData get _fallbackIcon {
    switch (channel.type) {
      case ContentType.live:
        return Icons.tv;
      case ContentType.movie:
        return Icons.movie_outlined;
      case ContentType.series:
        return Icons.video_library_outlined;
    }
  }

  @override
  Widget build(BuildContext context) {
    final fallback = Icon(_fallbackIcon, color: Colors.white54);
    return ListTile(
      onTap: onTap,
      leading: SizedBox(
        width: 52,
        height: 52,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: channel.logo == null
              ? Center(child: fallback)
              : CachedNetworkImage(
                  imageUrl: channel.logo!,
                  fit: BoxFit.contain,
                  placeholder: (_, __) => Center(child: fallback),
                  errorWidget: (_, __, ___) => Center(child: fallback),
                ),
        ),
      ),
      title: Text(channel.name, maxLines: 1, overflow: TextOverflow.ellipsis),
      subtitle: Text(channel.group, maxLines: 1, overflow: TextOverflow.ellipsis),
      onLongPress: onToggleFavorite,
      trailing: ExcludeFocus(
        child: IconButton(
          tooltip: isFavorite ? 'Retirer des favoris' : 'Ajouter aux favoris',
          icon: Icon(isFavorite ? Icons.star : Icons.star_border, color: isFavorite ? Colors.amber : null),
          onPressed: onToggleFavorite,
        ),
      ),
    );
  }
}

/// Carte pour la grille de contenus (logo de chaîne ou affiche de film/série).
///
/// Un seul élément focalisable par carte (la télécommande ne s'arrête qu'une fois) :
/// OK ouvre, OK maintenu (ou appui long, ou touche Menu/Info) bascule le favori.
class ChannelCard extends StatefulWidget {
  const ChannelCard({
    super.key,
    required this.channel,
    required this.isFavorite,
    required this.onTap,
    required this.onToggleFavorite,
    this.poster = false,
  });

  final Channel channel;
  final bool isFavorite;
  final VoidCallback onTap;
  final VoidCallback onToggleFavorite;
  final bool poster;

  @override
  State<ChannelCard> createState() => _ChannelCardState();
}

class _ChannelCardState extends State<ChannelCard> {
  final FocusNode _node = FocusNode(debugLabel: 'channel-card');
  bool _focused = false;
  bool _down = false;
  bool _longDone = false;

  @override
  void dispose() {
    _node.dispose();
    super.dispose();
  }

  KeyEventResult _onKey(FocusNode node, KeyEvent e) {
    final k = e.logicalKey;
    final isSelect = k == LogicalKeyboardKey.select ||
        k == LogicalKeyboardKey.enter ||
        k == LogicalKeyboardKey.numpadEnter ||
        k == LogicalKeyboardKey.gameButtonA;
    if (isSelect) {
      if (e is KeyDownEvent) {
        _down = true;
        _longDone = false;
      } else if (e is KeyRepeatEvent) {
        if (_down && !_longDone) {
          _longDone = true;
          widget.onToggleFavorite();
        }
      } else if (e is KeyUpEvent) {
        final fire = _down && !_longDone;
        _down = false;
        _longDone = false;
        if (fire) widget.onTap();
      }
      return KeyEventResult.handled;
    }
    if (e is KeyDownEvent &&
        (k == LogicalKeyboardKey.contextMenu || k == LogicalKeyboardKey.info || k == LogicalKeyboardKey.keyF)) {
      widget.onToggleFavorite();
      return KeyEventResult.handled;
    }
    return KeyEventResult.ignored;
  }

  @override
  Widget build(BuildContext context) {
    final poster = widget.poster;
    final channel = widget.channel;
    final fallback = Center(
      child: Icon(poster ? Icons.movie_outlined : Icons.tv, size: 40, color: Colors.white38),
    );
    Widget image = fallback;
    if (channel.logo != null) {
      final img = CachedNetworkImage(
        imageUrl: channel.logo!,
        fit: poster ? BoxFit.cover : BoxFit.contain,
        memCacheWidth: poster ? 340 : 240,
        fadeInDuration: const Duration(milliseconds: 120),
        placeholder: (_, __) => fallback,
        errorWidget: (_, __, ___) => fallback,
      );
      image = poster ? img : Padding(padding: const EdgeInsets.fromLTRB(16, 16, 16, 44), child: img);
    }
    final radius = BorderRadius.circular(14);
    return MouseRegion(
      onHover: (_) {
        if (!_node.hasFocus) _node.requestFocus();
      },
      child: Focus(
        focusNode: _node,
        onFocusChange: (f) {
          if (mounted) setState(() => _focused = f);
        },
        onKeyEvent: _onKey,
        child: GestureDetector(
          onTap: widget.onTap,
          onLongPress: widget.onToggleFavorite,
          child: AnimatedScale(
            scale: _focused ? 1.06 : 1.0,
            duration: const Duration(milliseconds: 120),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: radius,
                border: Border.all(color: _focused ? Colors.white : Colors.transparent, width: 3),
                boxShadow: _focused
                    ? [BoxShadow(color: const Color(0xFF22D3EE).withValues(alpha: 0.7), blurRadius: 22, spreadRadius: 1)]
                    : null,
              ),
              child: Card(
                clipBehavior: Clip.antiAlias,
                shape: RoundedRectangleBorder(borderRadius: radius),
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    image,
                    Positioned(
                      left: 0,
                      right: 0,
                      bottom: 0,
                      child: Container(
                        color: _focused ? const Color(0xE6006B80) : Colors.black54,
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                        child: Text(
                          channel.name,
                          maxLines: 2,
                          textAlign: TextAlign.center,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontSize: 12, color: Colors.white),
                        ),
                      ),
                    ),
                    Positioned(
                      top: 0,
                      right: 0,
                      child: ExcludeFocus(
                        child: GestureDetector(
                          behavior: HitTestBehavior.opaque,
                          onTap: widget.onToggleFavorite,
                          child: Padding(
                            padding: const EdgeInsets.all(8),
                            child: Icon(
                              widget.isFavorite ? Icons.star : Icons.star_border,
                              size: 22,
                              color: widget.isFavorite ? Colors.amber : Colors.white70,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
