import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../app/routes.dart';
import '../../core/utils/debouncer.dart';
import '../../core/utils/error_text.dart';
import '../../models/channel.dart';
import '../../services/network_settings.dart';
import '../../services/playlist_service.dart';
import '../../services/subscription_store.dart';
import '../player/player_screen.dart';
import 'channel_tile.dart';
import 'channels_controller.dart';

const String kFilterAll = '__all__';
const String kFilterFavorites = '__favorites__';
const String kFilterRecents = '__recents__';

/// Écran d'une section (Direct, Films ou Séries) :
/// catégories à gauche, contenus en grille à droite.
class ChannelsScreen extends StatefulWidget {
  const ChannelsScreen({super.key, required this.type, this.initialFilter = kFilterAll});

  final ContentType type;
  final String initialFilter;

  @override
  State<ChannelsScreen> createState() => _ChannelsScreenState();
}

class _ChannelsScreenState extends State<ChannelsScreen> {
  final Debouncer _debouncer = Debouncer(const Duration(milliseconds: 250));
  final TextEditingController _searchController = TextEditingController();
  late String _filter = widget.initialFilter;
  String _query = '';
  bool _searching = false;

  ContentType get _type => widget.type;
  bool get _poster => _type != ContentType.live;

  String get _title {
    switch (_type) {
      case ContentType.live:
        return 'Direct';
      case ContentType.movie:
        return 'Films';
      case ContentType.series:
        return 'Séries';
    }
  }

  @override
  void dispose() {
    _debouncer.dispose();
    _searchController.dispose();
    super.dispose();
  }

  void _reload() {
    final store = context.read<SubscriptionStore>();
    final sub = store.active;
    if (sub == null) return;
    context.read<ChannelsController>().load(sub, context.read<NetworkSettings>(), store, force: true);
  }

  List<Channel> _visible(SubscriptionStore store, ChannelsController controller) {
    Iterable<Channel> source;
    if (_filter == kFilterFavorites) {
      source = store.favorites.where((c) => c.type == _type);
    } else if (_filter == kFilterRecents) {
      source = store.recents.where((c) => c.type == _type);
    } else {
      source = controller.channelsOf(_type);
      if (_filter != kFilterAll) source = source.where((c) => c.group == _filter);
    }
    final q = _query.trim().toLowerCase();
    if (q.isNotEmpty) source = source.where((c) => c.name.toLowerCase().contains(q));
    return source.toList(growable: false);
  }

  Future<void> _open(List<Channel> list, int index) async {
    final channel = list[index];
    if (channel.isSeriesContainer) {
      await _openSeries(channel);
      return;
    }
    final controller = context.read<ChannelsController>();
    context.read<SubscriptionStore>().addRecent(channel);
    await Navigator.of(context).pushNamed(
      AppRoutes.player,
      arguments: PlayerArgs(channels: list, index: index, pool: controller.channelsOf(_type)),
    );
  }

  Future<void> _openSeries(Channel series) async {
    final store = context.read<SubscriptionStore>();
    final sub = store.active;
    if (sub == null) return;
    final service = PlaylistService(context.read<NetworkSettings>());
    final navigator = Navigator.of(context);

    final episodes = await showModalBottomSheet<List<Channel>>(
      context: context,
      isScrollControlled: true,
      builder: (sheetContext) {
        return DraggableScrollableSheet(
          expand: false,
          initialChildSize: 0.7,
          maxChildSize: 0.95,
          builder: (_, scroll) => FutureBuilder<List<Channel>>(
            future: service.episodes(sub, series),
            builder: (_, snapshot) {
              if (snapshot.connectionState != ConnectionState.done) {
                return const Center(child: CircularProgressIndicator());
              }
              if (snapshot.hasError) {
                return Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Text(frenchError(snapshot.error!), textAlign: TextAlign.center),
                  ),
                );
              }
              final list = snapshot.data ?? const <Channel>[];
              if (list.isEmpty) {
                return const Center(child: Text('Aucun épisode disponible.'));
              }
              return ListView.builder(
                controller: scroll,
                itemCount: list.length + 1,
                itemBuilder: (_, i) {
                  if (i == 0) {
                    return Padding(
                      padding: const EdgeInsets.all(16),
                      child: Text(series.name, style: Theme.of(context).textTheme.titleMedium),
                    );
                  }
                  final ep = list[i - 1];
                  return ListTile(
                    leading: const Icon(Icons.play_circle_outline),
                    title: Text(ep.name),
                    onTap: () => Navigator.of(sheetContext).pop(list.sublist(i - 1)),
                  );
                },
              );
            },
          ),
        );
      },
    );
    if (episodes == null || episodes.isEmpty) return;
    store.addRecent(series);
    await navigator.pushNamed(AppRoutes.player, arguments: PlayerArgs(channels: episodes, index: 0));
  }

  @override
  Widget build(BuildContext context) {
    final store = context.watch<SubscriptionStore>();
    final controller = context.watch<ChannelsController>();
    final active = store.active;

    return Scaffold(
      appBar: AppBar(
        title: _searching
            ? TextField(
                controller: _searchController,
                autofocus: true,
                decoration: const InputDecoration(hintText: 'Rechercher…', border: InputBorder.none, filled: false),
                onChanged: (v) => _debouncer.run(() {
                  if (mounted) setState(() => _query = v);
                }),
              )
            : Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(_title),
                  const Text(
                    'OK : ouvrir  ·  OK maintenu : favori',
                    style: TextStyle(fontSize: 11, color: Colors.white54, fontWeight: FontWeight.normal),
                  ),
                ],
              ),
        actions: [
          IconButton(
            tooltip: _searching ? 'Fermer la recherche' : 'Rechercher',
            icon: Icon(_searching ? Icons.close : Icons.search),
            onPressed: () => setState(() {
              _searching = !_searching;
              if (!_searching) {
                _searchController.clear();
                _query = '';
              }
            }),
          ),
          IconButton(tooltip: 'Actualiser', icon: const Icon(Icons.refresh), onPressed: _reload),
        ],
      ),
      body: _body(store, controller, active != null),
    );
  }

  Widget _body(SubscriptionStore store, ChannelsController controller, bool hasSubscription) {
    if (!hasSubscription) {
      return Center(
        child: FilledButton(
          onPressed: () => Navigator.of(context).pushNamed(AppRoutes.addSubscription),
          child: const Text('Ajouter un abonnement'),
        ),
      );
    }
    if (controller.loading) {
      return const Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [CircularProgressIndicator(), SizedBox(height: 16), Text('Chargement des chaînes…')],
        ),
      );
    }
    if (controller.error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(controller.error!, textAlign: TextAlign.center),
              const SizedBox(height: 16),
              FilledButton(onPressed: _reload, child: const Text('Réessayer')),
            ],
          ),
        ),
      );
    }

    final categories = controller.categoriesOf(_type);
    final visible = _visible(store, controller);
    final entries = <(String, String)>[
      ('Favoris', kFilterFavorites),
      ('Récents', kFilterRecents),
      ('Tous', kFilterAll),
      for (final c in categories) ('${c.name} (${c.count})', c.name),
    ];
    final content = _buildContent(store, controller, visible);

    return LayoutBuilder(
      builder: (context, box) {
        if (box.maxWidth >= 700) {
          final highlight = Theme.of(context).colorScheme.primary.withValues(alpha: 0.15);
          return Row(
            children: [
              SizedBox(
                width: 280,
                child: ListView.builder(
                  itemCount: entries.length,
                  itemBuilder: (_, i) {
                    final e = entries[i];
                    return ListTile(
                      dense: true,
                      selected: _filter == e.$2,
                      selectedTileColor: highlight,
                      focusColor: Theme.of(context).colorScheme.primary.withValues(alpha: 0.45),
                      title: Text(e.$1, maxLines: 2, overflow: TextOverflow.ellipsis),
                      onTap: () => setState(() => _filter = e.$2),
                    );
                  },
                ),
              ),
              const VerticalDivider(width: 1),
              Expanded(child: content),
            ],
          );
        }
        return Column(
          children: [
            SizedBox(
              height: 52,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                children: [
                  for (final e in entries)
                    Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: ChoiceChip(
                        label: Text(e.$1),
                        selected: _filter == e.$2,
                        onSelected: (_) => setState(() => _filter = e.$2),
                      ),
                    ),
                ],
              ),
            ),
            Expanded(child: content),
          ],
        );
      },
    );
  }

  Widget _buildContent(SubscriptionStore store, ChannelsController controller, List<Channel> visible) {
    if (visible.isEmpty) {
      if (controller.isPending(_type)) {
        return const Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [CircularProgressIndicator(), SizedBox(height: 16), Text('Chargement en cours…')],
          ),
        );
      }
      final err = controller.sectionError(_type);
      if (err != null && _filter == kFilterAll && _query.isEmpty) {
        return Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(err, textAlign: TextAlign.center),
                const SizedBox(height: 16),
                FilledButton(onPressed: _reload, child: const Text('Réessayer')),
              ],
            ),
          ),
        );
      }
      return const Center(child: Text('Aucun résultat.'));
    }
    final grid = GridView.builder(
      padding: const EdgeInsets.all(12),
      gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
        maxCrossAxisExtent: _poster ? 170 : 200,
        mainAxisSpacing: 12,
        crossAxisSpacing: 12,
        childAspectRatio: _poster ? 0.66 : 1.05,
      ),
      cacheExtent: 600,
      itemCount: visible.length,
      itemBuilder: (_, i) {
        final c = visible[i];
        return ChannelCard(
          key: ValueKey(c.key),
          channel: c,
          poster: _poster,
          isFavorite: store.isFavorite(c),
          onTap: () => _open(visible, i),
          onToggleFavorite: () => store.toggleFavorite(c),
        );
      },
    );
    if (!controller.isPending(_type)) return grid;
    return Column(
      children: [
        const LinearProgressIndicator(minHeight: 2),
        Expanded(child: grid),
      ],
    );
  }
}
