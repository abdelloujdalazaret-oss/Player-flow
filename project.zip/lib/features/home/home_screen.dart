import 'dart:math';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/channel.dart';
import '../../services/network_settings.dart';
import '../../services/subscription_store.dart';
import '../account/account_screen.dart';
import '../account/settings_screen.dart';
import '../channels/channels_controller.dart';
import '../channels/channels_screen.dart';
import 'ice_background.dart';

const Color _cyan = Color(0xFF38D5FF);

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String? _loadedFor;

  void _reload() {
    final store = context.read<SubscriptionStore>();
    final sub = store.active;
    if (sub == null) return;
    context.read<ChannelsController>().load(sub, context.read<NetworkSettings>(), store);
  }

  void _push(Widget page) {
    Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => page));
  }

  void _openSection(ContentType type, {String filter = kFilterAll}) {
    _push(ChannelsScreen(type: type, initialFilter: filter));
  }

  String? _count(ChannelsController controller, ContentType type) {
    final n = controller.channelsOf(type).length;
    if (n > 0) return '$n';
    if (controller.isPending(type) || controller.loading) return '…';
    if (controller.sectionError(type) != null) return 'Erreur';
    return null;
  }

  @override
  Widget build(BuildContext context) {
    final store = context.watch<SubscriptionStore>();
    final controller = context.watch<ChannelsController>();
    final active = store.active;
    if (active?.id != _loadedFor) {
      _loadedFor = active?.id;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _reload();
      });
    }

    return Scaffold(
      body: IceBackground(
        child: SafeArea(
          child: LayoutBuilder(
            builder: (context, box) {
              final w = box.maxWidth;
              final h = box.maxHeight;
              final circle = min((w - 72) / 3, h * 0.40).clamp(96.0, 240.0).toDouble();
              final tileScale = (min(w / 900, h / 560)).clamp(0.8, 1.4).toDouble();
              final logo = (h * 0.14).clamp(56.0, 110.0).toDouble();

              return Column(
                children: [
                  SizedBox(height: h * 0.02),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(logo * 0.26),
                    child: Image.asset('assets/images/logo.png', height: logo),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    active?.name ?? 'Aucun abonnement',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20 * tileScale,
                      fontWeight: FontWeight.w700,
                      shadows: const [Shadow(blurRadius: 8, color: Colors.black54)],
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'STREAMING  ·  LIVE  ·  ON DEMAND',
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 11 * tileScale,
                      letterSpacing: 3,
                      shadows: const [Shadow(blurRadius: 6, color: Colors.black54)],
                    ),
                  ),
                  Expanded(
                    child: Center(
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          _GlassCircle(
                            size: circle,
                            icon: Icons.live_tv_rounded,
                            label: 'Direct',
                            count: _count(controller, ContentType.live),
                            autofocus: true,
                            onTap: () => _openSection(ContentType.live),
                          ),
                          SizedBox(width: circle * 0.12),
                          _GlassCircle(
                            size: circle,
                            icon: Icons.movie_creation_outlined,
                            label: 'Films',
                            count: _count(controller, ContentType.movie),
                            onTap: () => _openSection(ContentType.movie),
                          ),
                          SizedBox(width: circle * 0.12),
                          _GlassCircle(
                            size: circle,
                            icon: Icons.video_library_outlined,
                            label: 'Séries',
                            count: _count(controller, ContentType.series),
                            onTap: () => _openSection(ContentType.series),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.fromLTRB(16, 0, 16, 14 * tileScale),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        _GlassTile(
                          scale: tileScale,
                          icon: Icons.person_outline_rounded,
                          label: 'Compte',
                          onTap: () => _push(const AccountScreen()),
                        ),
                        _GlassTile(
                          scale: tileScale,
                          icon: Icons.star_outline_rounded,
                          label: 'Favoris',
                          onTap: () => _openSection(ContentType.live, filter: kFilterFavorites),
                        ),
                        _GlassTile(
                          scale: tileScale,
                          icon: Icons.settings_outlined,
                          label: 'Paramètres',
                          onTap: () => _push(const SettingsScreen()),
                        ),
                      ],
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }
}

/// Zone cliquable avec mise en évidence au focus (télécommande / clavier) et effet de pression.
class _Pressable extends StatefulWidget {
  const _Pressable({
    required this.onTap,
    required this.builder,
    this.autofocus = false,
  });

  final VoidCallback onTap;
  final Widget Function(bool focused, bool pressed) builder;
  final bool autofocus;

  @override
  State<_Pressable> createState() => _PressableState();
}

class _PressableState extends State<_Pressable> {
  bool _focused = false;
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return FocusableActionDetector(
      autofocus: widget.autofocus,
      onShowFocusHighlight: (v) => setState(() => _focused = v),
      actions: {
        ActivateIntent: CallbackAction<ActivateIntent>(onInvoke: (_) {
          widget.onTap();
          return null;
        }),
      },
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: widget.onTap,
        onTapDown: (_) => setState(() => _pressed = true),
        onTapUp: (_) => setState(() => _pressed = false),
        onTapCancel: () => setState(() => _pressed = false),
        child: AnimatedScale(
          scale: _pressed ? 0.95 : (_focused ? 1.08 : 1.0),
          duration: const Duration(milliseconds: 140),
          curve: Curves.easeOut,
          child: widget.builder(_focused, _pressed),
        ),
      ),
    );
  }
}

class _GlassCircle extends StatelessWidget {
  const _GlassCircle({
    required this.size,
    required this.icon,
    required this.label,
    required this.onTap,
    this.count,
    this.autofocus = false,
  });

  final double size;
  final IconData icon;
  final String label;
  final String? count;
  final VoidCallback onTap;
  final bool autofocus;

  @override
  Widget build(BuildContext context) {
    return _Pressable(
      onTap: onTap,
      autofocus: autofocus,
      builder: (focused, pressed) => Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(color: _cyan.withValues(alpha: focused ? 0.75 : 0.40), blurRadius: focused ? 40 : 28, spreadRadius: focused ? 3 : 0),
          ],
        ),
        child: ClipOval(
          child: BackdropFilter(
            filter: ui.ImageFilter.blur(sigmaX: 14, sigmaY: 14),
            child: Container(
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  center: const Alignment(-0.35, -0.55),
                  radius: 1.1,
                  colors: [
                    Colors.white.withValues(alpha: 0.26),
                    const Color(0xFF0A3A73).withValues(alpha: 0.55),
                    const Color(0xFF05234A).withValues(alpha: 0.65),
                  ],
                  stops: const [0, 0.55, 1],
                ),
                border: Border.all(color: focused ? Colors.white : _cyan, width: focused ? 3 : 2.2),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(icon, size: size * 0.32, color: Colors.white),
                  SizedBox(height: size * 0.04),
                  Text(
                    label,
                    style: TextStyle(color: Colors.white, fontSize: size * 0.105, fontWeight: FontWeight.w700),
                  ),
                  if (count != null)
                    Text(count!, style: TextStyle(color: Colors.white70, fontSize: size * 0.065)),
                  SizedBox(height: size * 0.04),
                  Container(
                    width: size * 0.16,
                    height: 3,
                    decoration: BoxDecoration(color: _cyan, borderRadius: BorderRadius.circular(2)),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _GlassTile extends StatelessWidget {
  const _GlassTile({required this.scale, required this.icon, required this.label, required this.onTap});

  final double scale;
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final radius = BorderRadius.circular(22 * scale);
    return _Pressable(
      onTap: onTap,
      builder: (focused, pressed) => Container(
        width: 118 * scale,
        height: 84 * scale,
        decoration: BoxDecoration(
          borderRadius: radius,
          boxShadow: [BoxShadow(color: _cyan.withValues(alpha: focused ? 0.6 : 0.18), blurRadius: focused ? 26 : 16)],
        ),
        child: ClipRRect(
          borderRadius: radius,
          child: BackdropFilter(
            filter: ui.ImageFilter.blur(sigmaX: 12, sigmaY: 12),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: radius,
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Colors.white.withValues(alpha: 0.18),
                    const Color(0xFF07305F).withValues(alpha: 0.6),
                  ],
                ),
                border: Border.all(color: focused ? Colors.white : _cyan.withValues(alpha: 0.65), width: focused ? 2.5 : 1.4),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(icon, size: 30 * scale, color: Colors.white),
                  SizedBox(height: 4 * scale),
                  Text(label, style: TextStyle(color: Colors.white, fontSize: 13 * scale, fontWeight: FontWeight.w600)),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
