import 'dart:math';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

/// Fond cinématique : montagnes enneigées, glacier et lac au coucher du soleil.
/// Pour utiliser votre propre photo, ajoutez `assets/images/home_bg.jpg`.
class IceBackground extends StatelessWidget {
  const IceBackground({super.key, this.child});

  final Widget? child;

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        RepaintBoundary(
          child: Image.asset(
            'assets/images/home_bg.jpg',
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => const CustomPaint(painter: _IcePainter()),
          ),
        ),
        const DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Color(0x66030B1A), Color(0x00000000), Color(0x00000000), Color(0x80030B1A)],
              stops: [0, 0.3, 0.7, 1],
            ),
          ),
        ),
        if (child != null) child!,
      ],
    );
  }
}

class _IcePainter extends CustomPainter {
  const _IcePainter();

  static List<double> _ridge(int seed, {int n = 128, double rough = 0.55}) {
    final r = Random(seed);
    final pts = List<double>.filled(n + 1, 0);
    pts[0] = r.nextDouble();
    pts[n] = r.nextDouble();
    var step = n;
    var amp = 1.0;
    while (step > 1) {
      final half = step ~/ 2;
      for (var i = half; i < n; i += step) {
        pts[i] = (pts[i - half] + pts[i + half]) / 2 + (r.nextDouble() - 0.5) * amp;
      }
      amp *= rough;
      step = half;
    }
    final mn = pts.reduce(min);
    final mx = pts.reduce(max);
    return [for (final v in pts) (v - mn) / (mx - mn)];
  }

  void _mountains(Canvas c, Size size, double horizon) {
    final w = size.width;
    final h = size.height;
    final layers = [
      (seed: 7, amp: 0.30, lift: 0.02, valley: 0.15, haze: 0.45, tint: const Color(0xFF7FA6D6)),
      (seed: 21, amp: 0.38, lift: 0.0, valley: 0.55, haze: 0.18, tint: const Color(0xFF3E6EAA)),
    ];
    for (final l in layers) {
      final ridge = _ridge(l.seed);
      final n = ridge.length - 1;
      final path = Path()..moveTo(0, horizon + 2);
      var minY = horizon;
      for (var i = 0; i <= n; i++) {
        final x = w * i / n;
        final edge = pow((x / w - 0.5).abs() * 2, 1.15).toDouble();
        final f = l.valley + (1 - l.valley) * edge;
        final y = horizon - h * l.lift - pow(ridge[i], 1.25) * h * l.amp * f;
        if (y < minY) minY = y;
        path.lineTo(x, y);
      }
      path
        ..lineTo(w, horizon + 2)
        ..close();
      final paint = Paint()
        ..shader = ui.Gradient.linear(Offset(0, minY), Offset(0, horizon), [
          const Color(0xFFF2F8FF),
          const Color(0xFFC4DCF5),
          Color.lerp(l.tint, const Color(0xFF0E2A55), 0.4)!,
          Color.lerp(l.tint, const Color(0xFF081A3A), 0.75)!,
        ], const [0.0, 0.22, 0.55, 1.0]);
      c.drawPath(path, paint);
      // Brume entre les plans.
      c.drawRect(
        Rect.fromLTRB(0, minY, w, horizon),
        Paint()
          ..shader = ui.Gradient.linear(Offset(0, horizon - h * 0.12), Offset(0, horizon), [
            const Color(0x00BFD9F5),
            Color.fromRGBO(191, 217, 245, l.haze),
          ]),
      );
    }
  }

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final horizon = h * 0.66;

    // Ciel.
    canvas.drawRect(
      Offset.zero & size,
      Paint()
        ..shader = ui.Gradient.linear(Offset.zero, Offset(0, horizon), const [
          Color(0xFF040E24),
          Color(0xFF0B3A82),
          Color(0xFF3B86D1),
          Color(0xFFF2B27C),
        ], const [0.0, 0.4, 0.8, 1.0]),
    );

    // Lueur du soleil.
    final sun = Offset(w * 0.93, horizon - h * 0.05);
    canvas.drawRect(
      Rect.fromLTWH(0, 0, w, horizon),
      Paint()
        ..shader = ui.Gradient.radial(sun, w * 0.45, const [Color(0xCCFFC38A), Color(0x55FF9A5C), Color(0x00FF9A5C)], const [0, 0.35, 1]),
    );

    // Nuages doux.
    final rnd = Random(3);
    final cloud = Paint()
      ..color = const Color(0x22FFFFFF)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 22);
    for (var i = 0; i < 7; i++) {
      final cx = w * rnd.nextDouble();
      final cy = h * (0.06 + 0.2 * rnd.nextDouble());
      canvas.drawOval(Rect.fromCenter(center: Offset(cx, cy), width: w * (0.18 + 0.2 * rnd.nextDouble()), height: h * 0.035), cloud);
    }

    _mountains(canvas, size, horizon);

    // Lac : reflet des montagnes.
    final water = Rect.fromLTRB(0, horizon, w, h);
    canvas.save();
    canvas.clipRect(water);
    canvas.saveLayer(water, Paint()..color = const Color(0x73FFFFFF));
    canvas.translate(0, horizon * 2);
    canvas.scale(1, -1);
    _mountains(canvas, size, horizon);
    canvas.restore();
    canvas.restore();

    canvas.drawRect(
      water,
      Paint()
        ..shader = ui.Gradient.linear(Offset(0, horizon), Offset(0, h), const [
          Color(0x992B6CB0),
          Color(0xE60A2A57),
          Color(0xFF061428),
        ], const [0, 0.5, 1]),
    );

    // Reflet doré du soleil.
    canvas.drawRect(
      Rect.fromLTRB(sun.dx - w * 0.07, horizon, sun.dx + w * 0.07, h),
      Paint()
        ..shader = ui.Gradient.linear(Offset(0, horizon), Offset(0, h), const [Color(0x88FFC38A), Color(0x00FFC38A)]),
    );

    // Ondulations.
    final ripple = Paint()
      ..color = const Color(0x1AFFFFFF)
      ..strokeWidth = 1.2
      ..strokeCap = StrokeCap.round;
    final rr = Random(11);
    for (var i = 0; i < 70; i++) {
      final y = horizon + 6 + (h - horizon) * pow(rr.nextDouble(), 1.4);
      final x = w * rr.nextDouble();
      final len = w * (0.02 + 0.08 * rr.nextDouble());
      canvas.drawLine(Offset(x, y), Offset(x + len, y), ripple);
    }

    // Blocs de glace.
    final fr = Random(5);
    for (var i = 0; i < 9; i++) {
      final t = pow(fr.nextDouble(), 1.2).toDouble();
      final y = horizon + 10 + (h - horizon) * 0.8 * t;
      final scale = 0.5 + 1.6 * t;
      final x = w * fr.nextDouble();
      final bw = w * 0.07 * scale;
      final bh = h * 0.018 * scale;
      final top = Path()
        ..moveTo(x, y)
        ..lineTo(x + bw * 0.25, y - bh)
        ..lineTo(x + bw * 0.8, y - bh * 0.8)
        ..lineTo(x + bw, y)
        ..close();
      canvas.drawPath(top, Paint()..color = const Color(0xFFE6F3FF));
      final side = Path()
        ..moveTo(x, y)
        ..lineTo(x + bw, y)
        ..lineTo(x + bw * 0.9, y + bh * 0.55)
        ..lineTo(x + bw * 0.1, y + bh * 0.55)
        ..close();
      canvas.drawPath(side, Paint()..color = const Color(0xFF5FA8E6));
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
