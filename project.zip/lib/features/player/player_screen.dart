import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:media_kit/media_kit.dart';
import 'package:media_kit_video/media_kit_video.dart';
import 'package:provider/provider.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

import '../../app/theme.dart';
import '../../models/channel.dart';
import '../../services/network_settings.dart';
import '../../services/progress_store.dart';
import '../../services/subscription_store.dart';

class PlayerArgs {
  const PlayerArgs({required this.channels, required this.index, this.pool});

  final List<Channel> channels;
  final int index;

  /// Ensemble des chaînes de la section, pour changer de catégorie dans le lecteur.
  final List<Channel>? pool;
}

class PlayerScreen extends StatefulWidget {
  const PlayerScreen({super.key, required this.args});

  final PlayerArgs args;

  @override
  State<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen> {
  static const int _maxRetries = 3;

  late final Player _player = Player(
    configuration: PlayerConfiguration(
      // Grand tampon pour les films (4K) afin d'éviter les saccades.
      bufferSize: (widget.args.channels[widget.args.index].type == ContentType.live ? 64 : 96) * 1024 * 1024,
    ),
  );
  late final VideoController _controller = VideoController(_player);
  final List<StreamSubscription<dynamic>> _subscriptions = [];

  late int _index = widget.args.index;
  BoxFit _fit = BoxFit.contain;
  bool _controlsVisible = true;
  bool _playing = false;
  bool _buffering = true;
  String? _error;
  String? _status;
  int _retries = 0;
  double _volume = 100;
  Timer? _hideTimer;
  Timer? _retryTimer;
  Timer? _saveTimer;
  Timer? _hintTimer;
  Timer? _watchdog;
  final FocusNode _keys = FocusNode(debugLabel: 'player-keys');
  final FocusNode _playFocus = FocusNode(debugLabel: 'player-play');
  Duration _lastPos = Duration.zero;
  int _stalledTicks = 0;
  Duration? _resumeAt;
  bool _userPaused = false;
  Future<void>? _tuned;
  Duration? _pendingResume;
  String? _hint;
  double _speed = 1.0;
  double _tapX = 0;
  final ValueNotifier<Duration> _position = ValueNotifier(Duration.zero);
  final ValueNotifier<Duration> _duration = ValueNotifier(Duration.zero);

  late List<Channel> _list = widget.args.channels;
  bool _panelOpen = false;
  List<String> _panelGroups = const [];
  List<Channel> _panelItems = const [];
  String? _panelGroup;
  ScrollController? _panelScroll;

  Channel get _channel => _list[_index];
  bool get _isVod => _channel.type != ContentType.live;

  @override
  void initState() {
    super.initState();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    SystemChrome.setPreferredOrientations(const [
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    WakelockPlus.enable();

    _subscriptions.add(_player.stream.playing.listen((value) {
      if (!mounted) return;
      if (value) _retries = 0;
      setState(() => _playing = value);
    }));
    _subscriptions.add(_player.stream.buffering.listen((value) {
      if (mounted) setState(() => _buffering = value);
    }));
    _subscriptions.add(_player.stream.error.listen(_onError));
    _subscriptions.add(_player.stream.position.listen((p) => _position.value = p));
    _subscriptions.add(_player.stream.duration.listen(_onDuration));
    _subscriptions.add(_player.stream.completed.listen((done) {
      if (!done || !mounted) return;
      final dur = _duration.value;
      final pos = _position.value;
      // Fin prématurée (le serveur a coupé la connexion) : on reprend là où on s'est arrêté.
      if (_isVod && dur > Duration.zero && dur - pos > const Duration(seconds: 30)) {
        _recover();
      } else if (_channel.type == ContentType.series && _index < _list.length - 1) {
        _change(1);
      }
    }));
    _watchdog = Timer.periodic(const Duration(seconds: 5), (_) => _checkStall());
    _saveTimer = Timer.periodic(const Duration(seconds: 10), (_) => _saveProgress());

    _tuned = _tune();
    _open();
    _scheduleHide();
  }

  /// Réglages mpv : cache large, reconnexion réseau et décodage matériel (4K).
  Future<void> _tune() async {
    final dynamic native = _player.platform;
    Future<void> set(String key, String value) async {
      try {
        await native.setProperty(key, value);
      } catch (_) {}
    }

    final vod = _isVod;
    await set('cache', 'yes');
    await set('cache-secs', vod ? '120' : '30');
    await set('demuxer-readahead-secs', vod ? '120' : '30');
    await set('cache-pause-wait', vod ? '3' : '1');
    await set('network-timeout', '30');
    await set('stream-lavf-o', 'reconnect=1,reconnect_streamed=1,reconnect_at_eof=1,reconnect_delay_max=5');
  }

  void _onDuration(Duration d) {
    _duration.value = d;
    final resume = _pendingResume;
    if (resume != null && d > Duration.zero) {
      _pendingResume = null;
      _player.seek(resume);
      _showHint('Reprise à ${_fmt(resume)}');
    }
  }

  Future<void> _open() async {
    await _tuned;
    final headers = Map<String, String>.of(context.read<NetworkSettings>().requestHeaders);
    final agent = _channel.userAgent;
    if (agent != null && agent.isNotEmpty) headers['User-Agent'] = agent;
    _position.value = Duration.zero;
    _duration.value = Duration.zero;
    _userPaused = false;
    _stalledTicks = 0;
    final forced = _resumeAt;
    _resumeAt = null;
    _pendingResume = forced ?? (_isVod ? await ProgressStore.instance.resumeFor(_channel.key) : null);
    if (!mounted) return;
    try {
      await _player.open(Media(_openUrl, httpHeaders: headers));
      if (_speed != 1.0) await _player.setRate(_speed);
    } catch (_) {
      _onError('open');
    }
  }

  /// Chaînes Xtream en direct : si la lecture échoue, on alterne .ts <-> .m3u8
  /// à chaque nouvelle tentative (certains serveurs n'acceptent qu'un format).
  String get _openUrl {
    final u = _channel.url;
    if (_channel.type != ContentType.live || _retries.isEven || !u.contains('/live/')) return u;
    if (u.endsWith('.ts')) return '${u.substring(0, u.length - 3)}.m3u8';
    if (u.endsWith('.m3u8')) return '${u.substring(0, u.length - 5)}.ts';
    return u;
  }

  /// Surveille les arrêts spontanés (film ou série qui se fige ou s'arrête seul).
  void _checkStall() {
    if (!mounted || _error != null || _panelOpen) return;
    if (_retryTimer?.isActive ?? false) return;
    if (!_isVod) return;
    final dur = _duration.value;
    final pos = _position.value;
    final nearEnd = dur > Duration.zero && pos >= dur - const Duration(seconds: 20);
    var bad = false;
    if (_playing) {
      bad = pos == _lastPos;
    } else {
      bad = !_userPaused && !_buffering && pos > Duration.zero && !nearEnd;
    }
    _lastPos = pos;
    _stalledTicks = bad ? _stalledTicks + 1 : 0;
    if (_stalledTicks >= (_playing ? 6 : 2)) {
      _stalledTicks = 0;
      _recover();
    }
  }

  void _recover() {
    if (!mounted) return;
    final pos = _position.value;
    if (pos > const Duration(seconds: 5)) _resumeAt = pos;
    setState(() => _buffering = true);
    _showHint('Reconnexion…');
    _open();
  }

  void _saveProgress() {
    if (!_isVod) return;
    final pos = _position.value;
    final dur = _duration.value;
    if (dur <= Duration.zero) return;
    ProgressStore.instance.save(_channel.key, pos, dur);
  }

  void _showHint(String text) {
    _hintTimer?.cancel();
    setState(() => _hint = text);
    _hintTimer = Timer(const Duration(milliseconds: 900), () {
      if (mounted) setState(() => _hint = null);
    });
  }

  void _seekBy(int seconds) {
    final dur = _duration.value;
    if (dur <= Duration.zero) return;
    var target = _position.value + Duration(seconds: seconds);
    if (target < Duration.zero) target = Duration.zero;
    if (target > dur) target = dur;
    _player.seek(target);
    _showHint(seconds > 0 ? '+$seconds s' : '$seconds s');
  }

  static String _fmt(Duration d) {
    final h = d.inHours;
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return h > 0 ? '$h:$m:$s' : '$m:$s';
  }

  void _onError(String _) {
    if (!mounted || _error != null) return;
    if (_retryTimer?.isActive ?? false) return;
    if (_isVod && _position.value > const Duration(seconds: 5)) _resumeAt = _position.value;
    if (_retries < _maxRetries) {
      final delay = Duration(seconds: 1 << _retries);
      _retries++;
      setState(() => _status = 'Nouvelle tentative ($_retries/$_maxRetries)…');
      _retryTimer = Timer(delay, () {
        if (mounted) _open();
      });
    } else {
      setState(() {
        _error = 'Impossible de lire cette chaîne.';
        _status = null;
        _buffering = false;
        _controlsVisible = true;
      });
    }
  }

  void _retryNow() {
    _retryTimer?.cancel();
    _retries = 0;
    setState(() {
      _error = null;
      _status = null;
      _buffering = true;
    });
    _open();
  }

  void _change(int delta) {
    final count = _list.length;
    if (count < 2) return;
    _saveProgress();
    _resumeAt = null;
    _retryTimer?.cancel();
    _retries = 0;
    setState(() {
      _index = (_index + delta) % count;
      _error = null;
      _status = null;
      _buffering = true;
    });
    context.read<SubscriptionStore>().addRecent(_channel);
    _open();
    _scheduleHide();
  }

  void _scheduleHide() {
    _hideTimer?.cancel();
    _hideTimer = Timer(const Duration(seconds: 4), () {
      if (mounted && _error == null && !_panelOpen) {
        setState(() => _controlsVisible = false);
        _keys.requestFocus();
      }
    });
  }

  void _showControls({bool focusPlay = false}) {
    if (!_controlsVisible) setState(() => _controlsVisible = true);
    _scheduleHide();
    if (focusPlay) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted && _controlsVisible && !_panelOpen) _playFocus.requestFocus();
      });
    }
  }

  /// Télécommande : flèches, OK, touches multimédia et chaîne +/-.
  KeyEventResult _onKey(FocusNode node, KeyEvent e) {
    if (e is KeyUpEvent || _panelOpen) return KeyEventResult.ignored;
    final k = e.logicalKey;
    final multiple = _list.length > 1;

    if (k == LogicalKeyboardKey.mediaPlayPause || k == LogicalKeyboardKey.mediaPlay || k == LogicalKeyboardKey.mediaPause) {
      if (e is KeyDownEvent) {
        if (k == LogicalKeyboardKey.mediaPlay && _playing) return KeyEventResult.handled;
        if (k == LogicalKeyboardKey.mediaPause && !_playing) return KeyEventResult.handled;
        _togglePlay();
        _showControls();
      }
      return KeyEventResult.handled;
    }
    if (k == LogicalKeyboardKey.mediaTrackNext || k == LogicalKeyboardKey.channelUp) {
      if (e is KeyDownEvent && multiple) _change(1);
      return KeyEventResult.handled;
    }
    if (k == LogicalKeyboardKey.mediaTrackPrevious || k == LogicalKeyboardKey.channelDown) {
      if (e is KeyDownEvent && multiple) _change(-1);
      return KeyEventResult.handled;
    }
    if (k == LogicalKeyboardKey.mediaFastForward || k == LogicalKeyboardKey.mediaRewind) {
      if (_isVod) _seekBy(k == LogicalKeyboardKey.mediaFastForward ? 30 : -30);
      return KeyEventResult.handled;
    }
    if (k == LogicalKeyboardKey.contextMenu || k == LogicalKeyboardKey.info) {
      if (e is KeyDownEvent) _openPanel();
      return KeyEventResult.handled;
    }

    // Un bouton des commandes a le focus : la navigation normale s'applique.
    if (_controlsVisible && !_keys.hasPrimaryFocus) {
      _scheduleHide();
      return KeyEventResult.ignored;
    }

    final vod = _isVod;
    final isSelect = k == LogicalKeyboardKey.select ||
        k == LogicalKeyboardKey.enter ||
        k == LogicalKeyboardKey.numpadEnter ||
        k == LogicalKeyboardKey.gameButtonA;
    if (k == LogicalKeyboardKey.arrowLeft || k == LogicalKeyboardKey.arrowRight) {
      final right = k == LogicalKeyboardKey.arrowRight;
      if (vod) {
        _seekBy(right ? 10 : -10);
        _showControls();
      } else if (!right) {
        _openPanel();
      } else {
        _showControls(focusPlay: true);
      }
      return KeyEventResult.handled;
    }
    if (k == LogicalKeyboardKey.arrowUp || k == LogicalKeyboardKey.arrowDown) {
      if (!vod && multiple && !_controlsVisible) {
        if (e is KeyDownEvent) _change(k == LogicalKeyboardKey.arrowUp ? 1 : -1);
      } else {
        _showControls(focusPlay: true);
      }
      return KeyEventResult.handled;
    }
    if (isSelect) {
      if (e is KeyDownEvent) {
        if (vod) {
          _togglePlay();
          _showControls();
        } else {
          _showControls(focusPlay: true);
        }
      }
      return KeyEventResult.handled;
    }
    return KeyEventResult.ignored;
  }

  void _toggleControls() {
    if (_controlsVisible) {
      _hideTimer?.cancel();
      setState(() => _controlsVisible = false);
      _keys.requestFocus();
    } else {
      setState(() => _controlsVisible = true);
      _scheduleHide();
    }
  }

  void _togglePlay() {
    _userPaused = _playing;
    _player.playOrPause();
    _scheduleHide();
  }

  String _trackLabel(String id, String? title, String? language) {
    if (id == 'auto') return 'Automatique';
    if (id == 'no') return 'Désactivé';
    final parts = [
      if (title != null && title.isNotEmpty) title,
      if (language != null && language.isNotEmpty) language,
    ];
    return parts.isEmpty ? 'Piste $id' : parts.join(' · ');
  }

  Future<void> _showTracks(String title, List<String> labels, String currentLabel, void Function(int) onPick) async {
    _hideTimer?.cancel();
    await showModalBottomSheet<void>(
      context: context,
      builder: (sheetContext) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: Text(title, style: Theme.of(sheetContext).textTheme.titleMedium),
            ),
            for (var i = 0; i < labels.length; i++)
              ListTile(
                title: Text(labels[i]),
                trailing: labels[i] == currentLabel ? const Icon(Icons.check) : null,
                onTap: () {
                  onPick(i);
                  Navigator.of(sheetContext).pop();
                },
              ),
          ],
        ),
      ),
    );
    if (mounted) _scheduleHide();
  }

  void _pickAudio() {
    final tracks = _player.state.tracks.audio;
    final current = _player.state.track.audio;
    _showTracks(
      'Audio',
      [for (final t in tracks) _trackLabel(t.id, t.title, t.language)],
      _trackLabel(current.id, current.title, current.language),
      (i) => _player.setAudioTrack(tracks[i]),
    );
  }

  void _pickSubtitle() {
    final tracks = _player.state.tracks.subtitle;
    final current = _player.state.track.subtitle;
    _showTracks(
      'Sous-titres',
      [for (final t in tracks) _trackLabel(t.id, t.title, t.language)],
      _trackLabel(current.id, current.title, current.language),
      (i) => _player.setSubtitleTrack(tracks[i]),
    );
  }

  void _pickQuality() {
    final tracks = _player.state.tracks.video;
    final current = _player.state.track.video;
    _showTracks(
      'Qualité',
      [for (final t in tracks) _videoLabel(t)],
      _videoLabel(current),
      (i) => _player.setVideoTrack(tracks[i]),
    );
  }

  void _pickSpeed() {
    const speeds = [0.5, 0.75, 1.0, 1.25, 1.5, 2.0];
    String label(double v) => v == 1.0 ? 'Normale' : '${v}x';
    _showTracks(
      'Vitesse de lecture',
      [for (final v in speeds) label(v)],
      label(_speed),
      (i) {
        setState(() => _speed = speeds[i]);
        _player.setRate(speeds[i]);
      },
    );
  }

  String _videoLabel(VideoTrack t) {
    if (t.id == 'auto') return 'Automatique';
    if (t.id == 'no') return 'Désactivé';
    if (t.w != null && t.h != null) return '${t.w}×${t.h}';
    return _trackLabel(t.id, t.title, t.language);
  }

  bool get _hasQuality =>
      _player.state.tracks.video.where((t) => t.id != 'auto' && t.id != 'no').length > 1;

  Future<void> _showVolume() async {
    _hideTimer?.cancel();
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (_, setDialogState) => AlertDialog(
          title: const Text('Volume'),
          content: Slider(
            value: _volume,
            min: 0,
            max: 100,
            divisions: 20,
            label: '${_volume.round()} %',
            onChanged: (v) {
              setDialogState(() => _volume = v);
              _player.setVolume(v);
            },
          ),
          actions: [
            TextButton(onPressed: () => Navigator.of(dialogContext).pop(), child: const Text('Fermer')),
          ],
        ),
      ),
    );
    if (mounted) _scheduleHide();
  }

  @override
  void dispose() {
    _saveProgress();
    _hideTimer?.cancel();
    _retryTimer?.cancel();
    _saveTimer?.cancel();
    _watchdog?.cancel();
    _keys.dispose();
    _playFocus.dispose();
    _hintTimer?.cancel();
    for (final s in _subscriptions) {
      s.cancel();
    }
    _position.dispose();
    _duration.dispose();
    WakelockPlus.disable();
    SystemChrome.setPreferredOrientations(DeviceOrientation.values);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    _panelScroll?.dispose();
    unawaited(_player.dispose());
    super.dispose();
  }

  Widget _chip({required IconData icon, required String label, required VoidCallback onPressed}) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: Material(
        color: Colors.white.withValues(alpha: 0.12),
        shape: const StadiumBorder(side: BorderSide(color: Colors.white12)),
        child: InkWell(
          customBorder: const StadiumBorder(),
          focusColor: AppColors.accent.withValues(alpha: 0.55),
          onTap: onPressed,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(icon, color: Colors.white, size: 20),
                const SizedBox(width: 6),
                Text(label, style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w500)),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _round({required IconData icon, required VoidCallback? onPressed, String? tooltip, double size = 46}) {
    return Tooltip(
      message: tooltip ?? '',
      child: Material(
        color: Colors.white.withValues(alpha: onPressed == null ? 0.05 : 0.14),
        shape: const CircleBorder(side: BorderSide(color: Colors.white12)),
        child: InkWell(
          customBorder: const CircleBorder(),
          focusColor: AppColors.accent.withValues(alpha: 0.55),
          onTap: onPressed,
          child: SizedBox(
            width: size,
            height: size,
            child: Icon(icon, color: onPressed == null ? Colors.white30 : Colors.white, size: size * 0.52),
          ),
        ),
      ),
    );
  }

  Widget _playButton() {
    return Container(
      width: 76,
      height: 76,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: AppColors.accent,
        boxShadow: [BoxShadow(color: AppColors.accent.withValues(alpha: 0.45), blurRadius: 24, spreadRadius: 1)],
      ),
      child: Material(
        type: MaterialType.transparency,
        child: InkWell(
          customBorder: const CircleBorder(),
          focusNode: _playFocus,
          focusColor: Colors.white54,
          onTap: _togglePlay,
          child: Icon(_playing ? Icons.pause_rounded : Icons.play_arrow_rounded, color: Colors.black, size: 46),
        ),
      ),
    );
  }

  Widget _liveBadge() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(color: const Color(0xFFE5484D), borderRadius: BorderRadius.circular(20)),
      child: const Text('EN DIRECT',
          style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 0.6)),
    );
  }

  Widget _seekBar() {
    return ValueListenableBuilder<Duration>(
      valueListenable: _duration,
      builder: (_, duration, __) => _SeekBar(
        position: _position,
        duration: duration,
        format: _fmt,
        onSeek: (d) => _player.seek(d),
        onDragStart: () => _hideTimer?.cancel(),
        onDragEnd: _scheduleHide,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final padding = MediaQuery.paddingOf(context);
    final multiple = _list.length > 1;
    final vod = _isVod;

    return PopScope(
      canPop: !_panelOpen,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _closePanel();
      },
      child: Focus(
        focusNode: _keys,
        autofocus: true,
        onKeyEvent: _onKey,
        child: Scaffold(
        backgroundColor: Colors.black,
        body: Stack(
          children: [
            Positioned.fill(
              child: Video(
                controller: _controller,
                fit: _fit,
                controls: NoVideoControls,
              ),
            ),
            Positioned.fill(
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: _toggleControls,
                onDoubleTapDown: (d) => _tapX = d.localPosition.dx,
                onDoubleTap: () {
                  if (!vod) return;
                  final width = MediaQuery.sizeOf(context).width;
                  _seekBy(_tapX < width / 2 ? -10 : 10);
                },
              ),
            ),
            if (_buffering && _error == null)
              const Center(child: CircularProgressIndicator(color: AppColors.accent)),
            if (_hint != null)
              Positioned(
                top: 72,
                left: 0,
                right: 0,
                child: Center(
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(20)),
                    child: Text(_hint!, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
                  ),
                ),
              ),
            if (_status != null && _error == null)
              Positioned(
                left: 0,
                right: 0,
                bottom: 120,
                child: Center(
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(20)),
                    child: Text(_status!, style: const TextStyle(color: Colors.white)),
                  ),
                ),
              ),
            if (_error != null)
              Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.error_outline_rounded, color: Colors.white70, size: 48),
                    const SizedBox(height: 8),
                    Text(_error!, style: const TextStyle(color: Colors.white, fontSize: 16)),
                    const SizedBox(height: 16),
                    FilledButton(onPressed: _retryNow, child: const Text('Réessayer')),
                  ],
                ),
              ),
            Positioned.fill(
              child: ExcludeFocus(
                excluding: !_controlsVisible || _panelOpen,
                child: IgnorePointer(
                ignoring: !_controlsVisible,
                child: AnimatedOpacity(
                  opacity: _controlsVisible ? 1 : 0,
                  duration: const Duration(milliseconds: 200),
                  child: Stack(
                    children: [
                      Positioned(
                        top: 0,
                        left: 0,
                        right: 0,
                        child: Container(
                          padding: EdgeInsets.fromLTRB(12 + padding.left, 10 + padding.top, 12 + padding.right, 24),
                          decoration: const BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: [Colors.black87, Colors.transparent],
                            ),
                          ),
                          child: Row(
                            children: [
                              _round(
                                icon: Icons.arrow_back_rounded,
                                tooltip: 'Retour',
                                onPressed: () => Navigator.of(context).maybePop(),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      _channel.name,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w700),
                                    ),
                                    if (_channel.group.isNotEmpty)
                                      Text(
                                        _channel.group,
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: const TextStyle(color: Colors.white60, fontSize: 12),
                                      ),
                                  ],
                                ),
                              ),
                              if (!vod) ...[_liveBadge(), const SizedBox(width: 12)],
                              _round(
                                icon: _fit == BoxFit.contain ? Icons.fit_screen_rounded : Icons.fullscreen_exit_rounded,
                                tooltip: _fit == BoxFit.contain ? 'Remplir' : 'Ajuster',
                                onPressed: () {
                                  setState(() => _fit = _fit == BoxFit.contain ? BoxFit.cover : BoxFit.contain);
                                  _scheduleHide();
                                },
                              ),
                            ],
                          ),
                        ),
                      ),
                      Center(
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            _round(
                              icon: Icons.skip_previous_rounded,
                              tooltip: 'Précédent',
                              onPressed: multiple ? () => _change(-1) : null,
                            ),
                            if (vod) ...[
                              const SizedBox(width: 18),
                              _round(icon: Icons.replay_10_rounded, tooltip: 'Reculer de 10 s', onPressed: () => _seekBy(-10)),
                            ],
                            const SizedBox(width: 22),
                            _playButton(),
                            const SizedBox(width: 22),
                            if (vod) ...[
                              _round(icon: Icons.forward_10_rounded, tooltip: 'Avancer de 10 s', onPressed: () => _seekBy(10)),
                              const SizedBox(width: 18),
                            ],
                            _round(
                              icon: Icons.skip_next_rounded,
                              tooltip: 'Suivant',
                              onPressed: multiple ? () => _change(1) : null,
                            ),
                          ],
                        ),
                      ),
                      Positioned(
                        left: 0,
                        right: 0,
                        bottom: 0,
                        child: Container(
                          padding: EdgeInsets.fromLTRB(16 + padding.left, 28, 16 + padding.right, 10 + padding.bottom),
                          decoration: const BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.bottomCenter,
                              end: Alignment.topCenter,
                              colors: [Colors.black87, Colors.transparent],
                            ),
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              if (vod) ExcludeFocus(child: _seekBar()),
                              const SizedBox(height: 4),
                              SingleChildScrollView(
                                scrollDirection: Axis.horizontal,
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    _chip(icon: Icons.view_list_rounded, label: 'Liste', onPressed: _openPanel),
                                    _chip(icon: Icons.volume_up_rounded, label: 'Volume', onPressed: _showVolume),
                                    _chip(icon: Icons.graphic_eq_rounded, label: 'Audio', onPressed: _pickAudio),
                                    _chip(icon: Icons.subtitles_rounded, label: 'Sous-titres', onPressed: _pickSubtitle),
                                    if (vod)
                                      _chip(
                                        icon: Icons.speed_rounded,
                                        label: _speed == 1.0 ? 'Vitesse' : '${_speed}x',
                                        onPressed: _pickSpeed,
                                      ),
                                    if (_hasQuality)
                                      _chip(icon: Icons.high_quality_rounded, label: 'Qualité', onPressed: _pickQuality),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              ),
            ),
            if (_panelOpen) ..._panelWidgets(padding),
          ],
        ),
      ),
      ),
    );
  }

  void _openPanel() {
    _hideTimer?.cancel();
    final pool = widget.args.pool ?? widget.args.channels;
    final groups = <String>{for (final c in pool) c.group}.toList()
      ..sort((a, b) => a.toLowerCase().compareTo(b.toLowerCase()));
    _panelGroups = groups;
    _setPanelGroup(_channel.group, notify: false);
    final current = _panelItems.indexWhere((c) => c.key == _channel.key);
    _panelScroll?.dispose();
    _panelScroll = ScrollController(
      initialScrollOffset: current > 2 ? (current - 2) * 56.0 : 0,
    );
    setState(() => _panelOpen = true);
  }

  void _closePanel() {
    setState(() => _panelOpen = false);
    _keys.requestFocus();
    _scheduleHide();
  }

  void _setPanelGroup(String group, {bool notify = true}) {
    final pool = widget.args.pool ?? widget.args.channels;
    final items = [for (final c in pool) if (c.group == group) c];
    if (notify) {
      setState(() {
        _panelGroup = group;
        _panelItems = items;
      });
      _panelScroll?.jumpTo(0);
    } else {
      _panelGroup = group;
      _panelItems = items;
    }
  }

  void _playFromPanel(int i) {
    _saveProgress();
    _resumeAt = null;
    _retryTimer?.cancel();
    _retries = 0;
    setState(() {
      _list = _panelItems;
      _index = i;
      _error = null;
      _status = null;
      _buffering = true;
      _panelOpen = false;
    });
    _keys.requestFocus();
    context.read<SubscriptionStore>().addRecent(_channel);
    _open();
    _scheduleHide();
  }

  List<Widget> _panelWidgets(EdgeInsets padding) {
    final group = _panelGroups.contains(_panelGroup) ? _panelGroup : null;
    return [
      Positioned.fill(
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: _closePanel,
          child: const ColoredBox(color: Colors.black26),
        ),
      ),
      Positioned(
        top: 0,
        bottom: 0,
        left: 0,
        width: 340,
        child: FocusScope(
          autofocus: true,
          onKeyEvent: (node, e) {
            if (e is KeyDownEvent && e.logicalKey == LogicalKeyboardKey.arrowRight) {
              _closePanel();
              return KeyEventResult.handled;
            }
            return KeyEventResult.ignored;
          },
          child: Material(
          color: const Color(0xF2101826),
          child: Padding(
            padding: EdgeInsets.only(top: padding.top, left: padding.left, bottom: padding.bottom),
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(4, 4, 12, 4),
                  child: Row(
                    children: [
                      IconButton(
                        tooltip: 'Fermer la liste',
                        icon: const Icon(Icons.close_rounded),
                        onPressed: _closePanel,
                      ),
                      Expanded(
                        child: DropdownButton<String>(
                          isExpanded: true,
                          value: group,
                          hint: const Text('Catégorie'),
                          items: [
                            for (final g in _panelGroups)
                              DropdownMenuItem(value: g, child: Text(g, maxLines: 1, overflow: TextOverflow.ellipsis)),
                          ],
                          onChanged: (g) {
                            if (g != null) _setPanelGroup(g);
                          },
                        ),
                      ),
                    ],
                  ),
                ),
                const Divider(height: 1),
                Expanded(
                  child: ListView.builder(
                    controller: _panelScroll,
                    itemExtent: 56,
                    itemCount: _panelItems.length,
                    itemBuilder: (_, i) {
                      final c = _panelItems[i];
                      final selected = c.key == _channel.key;
                      return ListTile(
                        dense: true,
                        selected: selected,
                        autofocus: selected,
                        focusColor: AppColors.accent.withValues(alpha: 0.4),
                        leading: Icon(selected ? Icons.play_arrow_rounded : Icons.tv_rounded, size: 20),
                        title: Text(c.name, maxLines: 2, overflow: TextOverflow.ellipsis),
                        onTap: () => _playFromPanel(i),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
        ),
      ),
    ];
  }
}

/// Barre de progression moderne (films et épisodes uniquement).
class _SeekBar extends StatefulWidget {
  const _SeekBar({
    required this.position,
    required this.duration,
    required this.format,
    required this.onSeek,
    required this.onDragStart,
    required this.onDragEnd,
  });

  final ValueNotifier<Duration> position;
  final Duration duration;
  final String Function(Duration) format;
  final void Function(Duration) onSeek;
  final VoidCallback onDragStart;
  final VoidCallback onDragEnd;

  @override
  State<_SeekBar> createState() => _SeekBarState();
}

class _SeekBarState extends State<_SeekBar> {
  double? _drag;

  @override
  Widget build(BuildContext context) {
    final total = widget.duration.inMilliseconds.toDouble();
    return ValueListenableBuilder<Duration>(
      valueListenable: widget.position,
      builder: (_, pos, __) {
        final max = total <= 0 ? 1.0 : total;
        final value = (_drag ?? pos.inMilliseconds.toDouble()).clamp(0.0, max);
        final shown = Duration(milliseconds: value.round());
        return Row(
          children: [
            SizedBox(
              width: 52,
              child: Text(widget.format(shown), style: const TextStyle(color: Colors.white, fontSize: 12)),
            ),
            Expanded(
              child: SliderTheme(
                data: SliderTheme.of(context).copyWith(
                  trackHeight: 4,
                  activeTrackColor: AppColors.accent,
                  inactiveTrackColor: Colors.white24,
                  thumbColor: AppColors.accent,
                  overlayColor: AppColors.accent.withValues(alpha: 0.2),
                  thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 7),
                ),
                child: Slider(
                  value: value,
                  max: max,
                  onChangeStart: total <= 0
                      ? null
                      : (_) {
                          widget.onDragStart();
                        },
                  onChanged: total <= 0 ? null : (v) => setState(() => _drag = v),
                  onChangeEnd: total <= 0
                      ? null
                      : (v) {
                          widget.onSeek(Duration(milliseconds: v.round()));
                          setState(() => _drag = null);
                          widget.onDragEnd();
                        },
                ),
              ),
            ),
            SizedBox(
              width: 52,
              child: Text(
                widget.format(widget.duration),
                textAlign: TextAlign.end,
                style: const TextStyle(color: Colors.white70, fontSize: 12),
              ),
            ),
          ],
        );
      },
    );
  }
}
