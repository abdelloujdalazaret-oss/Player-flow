import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../app/constants.dart';
import '../../app/routes.dart';
import '../../core/utils/error_text.dart';
import '../../models/subscription.dart';
import '../../services/network_settings.dart';
import '../../services/playlist_service.dart';
import '../../services/subscription_store.dart';

class AddSubscriptionArgs {
  const AddSubscriptionArgs({this.firstRun = false, this.editing});

  final bool firstRun;
  final Subscription? editing;
}

class AddSubscriptionScreen extends StatefulWidget {
  const AddSubscriptionScreen({super.key, this.args = const AddSubscriptionArgs()});

  final AddSubscriptionArgs args;

  @override
  State<AddSubscriptionScreen> createState() => _AddSubscriptionScreenState();
}

class _AddSubscriptionScreenState extends State<AddSubscriptionScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _name;
  late final TextEditingController _url;
  late final TextEditingController _server;
  late final TextEditingController _username;
  late final TextEditingController _password;
  late SubscriptionType _type;
  bool _busy = false;
  bool _hidePassword = true;
  String? _message;
  bool _messageOk = false;

  Subscription? get _editing => widget.args.editing;

  @override
  void initState() {
    super.initState();
    final e = _editing;
    _type = e?.type ?? SubscriptionType.m3u;
    _name = TextEditingController(text: e?.name ?? '');
    _url = TextEditingController(text: e?.type == SubscriptionType.m3u ? e?.url : '');
    _server = TextEditingController(text: e?.type == SubscriptionType.xtream ? e?.url : '');
    _username = TextEditingController(text: e?.username ?? '');
    _password = TextEditingController(text: e?.password ?? '');
  }

  @override
  void dispose() {
    _name.dispose();
    _url.dispose();
    _server.dispose();
    _username.dispose();
    _password.dispose();
    super.dispose();
  }

  Subscription _build() {
    final isM3u = _type == SubscriptionType.m3u;
    return Subscription(
      id: _editing?.id ?? DateTime.now().microsecondsSinceEpoch.toString(),
      name: _name.text.trim(),
      type: _type,
      url: (isM3u ? _url.text : _server.text).trim(),
      username: isM3u ? '' : _username.text.trim(),
      password: isM3u ? '' : _password.text,
    );
  }

  /// Si l'adresse collée contient username= et password=, remplit les champs.
  void _extractCredentials(String value) {
    final uri = Uri.tryParse(value.trim());
    if (uri == null || !uri.hasAuthority) return;
    final user = uri.queryParameters['username'];
    final pass = uri.queryParameters['password'];
    if (user == null || pass == null) return;
    _username.text = user;
    _password.text = pass;
    _server.text = '${uri.scheme}://${uri.host}${uri.hasPort ? ':${uri.port}' : ''}';
  }

  Future<void> _paste() async {
    final data = await Clipboard.getData(Clipboard.kTextPlain);
    final text = data?.text?.trim();
    if (text != null && text.isNotEmpty) _url.text = text;
  }

  Future<void> _run({required bool save}) async {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    final net = context.read<NetworkSettings>();
    final store = context.read<SubscriptionStore>();
    final navigator = Navigator.of(context);
    final firstRun = widget.args.firstRun;
    final sub = _build();

    setState(() {
      _busy = true;
      _message = null;
    });
    try {
      final result = await PlaylistService(net).test(sub);
      if (save) {
        await store.save(sub.copyWith(status: 'Valide'));
        await store.setActive(sub.id);
        if (firstRun) {
          navigator.pushNamedAndRemoveUntil(AppRoutes.home, (_) => false);
        } else {
          navigator.pop();
        }
        return;
      }
      if (mounted) {
        setState(() {
          _message = result;
          _messageOk = true;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _message = '${frenchError(e)}\n\n${AppConstants.blockedHint}';
          _messageOk = false;
        });
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  String? _required(String? v) => (v == null || v.trim().isEmpty) ? 'Ce champ est obligatoire.' : null;

  @override
  Widget build(BuildContext context) {
    final isM3u = _type == SubscriptionType.m3u;
    return Scaffold(
      appBar: AppBar(title: Text(_editing == null ? 'Ajouter un abonnement' : "Modifier l'abonnement")),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            SegmentedButton<SubscriptionType>(
              segments: const [
                ButtonSegment(value: SubscriptionType.m3u, label: Text('M3U')),
                ButtonSegment(value: SubscriptionType.xtream, label: Text('Xtream Codes')),
              ],
              selected: {_type},
              onSelectionChanged: _editing != null || _busy
                  ? null
                  : (s) => setState(() {
                        _type = s.first;
                        _message = null;
                      }),
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _name,
              decoration: const InputDecoration(labelText: 'Nom'),
              autofocus: true,
              validator: _required,
              textInputAction: TextInputAction.next,
            ),
            const SizedBox(height: 12),
            if (isM3u)
              TextFormField(
                controller: _url,
                keyboardType: TextInputType.url,
                decoration: InputDecoration(
                  labelText: 'URL M3U',
                  suffixIcon: TextButton(onPressed: _paste, child: const Text('Coller')),
                ),
                validator: (v) {
                  final r = _required(v);
                  if (r != null) return r;
                  final uri = Uri.tryParse(v!.trim());
                  if (uri == null || !uri.hasScheme || uri.host.isEmpty) return "L'URL est invalide.";
                  return null;
                },
                textInputAction: TextInputAction.done,
                onFieldSubmitted: (_) => _busy ? null : _run(save: true),
              )
            else ...[
              const Padding(
                padding: EdgeInsets.only(bottom: 8),
                child: Text(
                  'Astuce : collez le lien complet (…/get.php?username=…&password=…) dans « Serveur », '
                  "l'identifiant et le mot de passe seront remplis automatiquement.",
                  style: TextStyle(fontSize: 12, color: Colors.white60),
                ),
              ),
              TextFormField(
                controller: _server,
                keyboardType: TextInputType.url,
                decoration: const InputDecoration(labelText: 'Serveur', hintText: 'http://exemple.com:8080'),
                onChanged: _extractCredentials,
                validator: _required,
                textInputAction: TextInputAction.next,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _username,
                decoration: const InputDecoration(labelText: 'Identifiant'),
                validator: _required,
                textInputAction: TextInputAction.next,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _password,
                obscureText: _hidePassword,
                decoration: InputDecoration(
                  labelText: 'Mot de passe',
                  suffixIcon: IconButton(
                    tooltip: _hidePassword ? 'Afficher' : 'Masquer',
                    icon: Icon(_hidePassword ? Icons.visibility : Icons.visibility_off),
                    onPressed: () => setState(() => _hidePassword = !_hidePassword),
                  ),
                ),
                validator: _required,
                textInputAction: TextInputAction.done,
                onFieldSubmitted: (_) => _busy ? null : _run(save: true),
              ),
            ],
            const SizedBox(height: 16),
            if (_message != null)
              Container(
                padding: const EdgeInsets.all(12),
                margin: const EdgeInsets.only(bottom: 16),
                decoration: BoxDecoration(
                  color: (_messageOk ? Colors.green : Colors.redAccent).withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(_message!),
              ),
            OutlinedButton(
              onPressed: _busy ? null : () => _run(save: false),
              child: const Text('Tester la connexion'),
            ),
            const SizedBox(height: 12),
            FilledButton(
              onPressed: _busy ? null : () => _run(save: true),
              child: _busy
                  ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Text('Enregistrer'),
            ),
            const SizedBox(height: 16),
            const Text(
              AppConstants.legalNotice,
              style: TextStyle(fontSize: 12, color: Colors.white54),
            ),
          ],
        ),
      ),
    );
  }
}
