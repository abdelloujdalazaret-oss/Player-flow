import 'package:flutter/material.dart';

import '../../app/constants.dart';

enum LegalPage { privacy, terms, about }

class LegalScreen extends StatelessWidget {
  const LegalScreen({super.key, required this.page});

  final LegalPage page;

  String get _title {
    switch (page) {
      case LegalPage.privacy:
        return 'Politique de confidentialité';
      case LegalPage.terms:
        return "Conditions d'utilisation";
      case LegalPage.about:
        return 'À propos';
    }
  }

  List<(String, String)> get _sections {
    switch (page) {
      case LegalPage.privacy:
        return const [
          ('Avis important', AppConstants.legalNotice),
          (
            'Données enregistrées',
            "Vos abonnements (adresses, identifiants et mots de passe) sont enregistrés uniquement sur votre appareil. "
                "Les informations sensibles sont conservées dans le stockage sécurisé d'Android."
          ),
          (
            'Aucune collecte',
            "Player Flow ne collecte, ne transmet et ne vend aucune donnée personnelle. "
                "Les connexions sont établies directement entre votre appareil et les serveurs que vous avez ajoutés."
          ),
          (
            'Suppression',
            "Vous pouvez supprimer un abonnement à tout moment depuis l'onglet Compte. "
                "La désinstallation de l'application efface toutes les données locales."
          ),
        ];
      case LegalPage.terms:
        return const [
          ('Avis important', AppConstants.legalNotice),
          (
            'Usage autorisé',
            "Player Flow est un lecteur multimédia. Vous ne devez ajouter que des sources légales "
                "et respecter les droits des éditeurs de contenus."
          ),
          (
            'Responsabilité',
            "L'application est fournie sans garantie. L'éditeur n'est pas responsable des contenus lus, "
                "ni de la disponibilité des services tiers."
          ),
        ];
      case LegalPage.about:
        return const [
          ('Nom', AppConstants.appName),
          ('Version', AppConstants.version),
          ('Description', AppConstants.description),
          ('Avis', AppConstants.legalNotice),
        ];
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(_title)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          for (final (heading, body) in _sections) ...[
            Text(heading, style: theme.textTheme.titleMedium?.copyWith(color: theme.colorScheme.primary)),
            const SizedBox(height: 6),
            Text(body, style: theme.textTheme.bodyMedium),
            const SizedBox(height: 20),
          ],
        ],
      ),
    );
  }
}
