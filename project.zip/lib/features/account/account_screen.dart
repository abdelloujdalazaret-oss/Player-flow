import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../app/constants.dart';
import '../../app/routes.dart';
import '../../models/subscription.dart';
import '../../services/subscription_store.dart';
import 'add_subscription_screen.dart';
import 'legal_screen.dart';
import 'settings_screen.dart';

class AccountScreen extends StatelessWidget {
  const AccountScreen({super.key});

  Future<void> _confirmDelete(BuildContext context, Subscription sub) async {
    final store = context.read<SubscriptionStore>();
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text("Supprimer l'abonnement ?"),
        content: Text('« ${sub.name} » sera supprimé de cet appareil.'),
        actions: [
          TextButton(onPressed: () => Navigator.of(c).pop(false), child: const Text('Annuler')),
          FilledButton(onPressed: () => Navigator.of(c).pop(true), child: const Text('Supprimer')),
        ],
      ),
    );
    if (ok == true) await store.remove(sub.id);
  }

  Future<void> _openSupport(BuildContext context) async {
    final messenger = ScaffoldMessenger.of(context);
    final hasEmail = AppConstants.supportEmail.isNotEmpty;
    final hasWhatsapp = AppConstants.supportWhatsapp.isNotEmpty;
    if (!hasEmail && !hasWhatsapp) {
      messenger.showSnackBar(const SnackBar(content: Text("Les coordonnées d'assistance ne sont pas encore configurées.")));
      return;
    }
    final choice = await showModalBottomSheet<String>(
      context: context,
      builder: (c) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (hasEmail)
              ListTile(
                leading: const Icon(Icons.email_outlined),
                title: const Text('Email'),
                subtitle: const Text(AppConstants.supportEmail),
                onTap: () => Navigator.of(c).pop('email'),
              ),
            if (hasWhatsapp)
              ListTile(
                leading: const Icon(Icons.chat_outlined),
                title: const Text('WhatsApp'),
                onTap: () => Navigator.of(c).pop('whatsapp'),
              ),
          ],
        ),
      ),
    );
    if (choice == null) return;
    final uri = choice == 'email'
        ? Uri(scheme: 'mailto', path: AppConstants.supportEmail)
        : Uri.parse('https://wa.me/${AppConstants.supportWhatsapp}');
    try {
      final launched = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!launched) throw Exception();
    } catch (_) {
      messenger.showSnackBar(const SnackBar(content: Text("Impossible d'ouvrir l'application correspondante.")));
    }
  }

  void _openLegal(BuildContext context, LegalPage page) {
    Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => LegalScreen(page: page)));
  }

  @override
  Widget build(BuildContext context) {
    final store = context.watch<SubscriptionStore>();
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(title: const Text('Compte')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('Abonnements', style: theme.textTheme.titleMedium),
          const SizedBox(height: 8),
          if (store.subscriptions.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 16),
              child: Text("Aucun abonnement enregistré."),
            ),
          for (final sub in store.subscriptions)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Card(
                child: ListTile(
                  leading: Icon(
                    sub.id == store.activeId ? Icons.check_circle : Icons.circle_outlined,
                    color: sub.id == store.activeId ? theme.colorScheme.primary : null,
                  ),
                  title: Text(sub.name),
                  subtitle: Text('${sub.typeLabel} · ${sub.status}${sub.id == store.activeId ? ' · Actif' : ''}'),
                  trailing: PopupMenuButton<String>(
                    onSelected: (action) {
                      switch (action) {
                        case 'select':
                          store.setActive(sub.id);
                        case 'edit':
                          Navigator.of(context).pushNamed(
                            AppRoutes.addSubscription,
                            arguments: AddSubscriptionArgs(editing: sub),
                          );
                        case 'delete':
                          _confirmDelete(context, sub);
                      }
                    },
                    itemBuilder: (_) => const [
                      PopupMenuItem(value: 'select', child: Text('Sélectionner')),
                      PopupMenuItem(value: 'edit', child: Text('Modifier')),
                      PopupMenuItem(value: 'delete', child: Text('Supprimer')),
                    ],
                  ),
                  onTap: () => store.setActive(sub.id),
                ),
              ),
            ),
          const SizedBox(height: 8),
          FilledButton.icon(
            onPressed: () => Navigator.of(context).pushNamed(AppRoutes.addSubscription),
            icon: const Icon(Icons.add),
            label: const Text('Ajouter un abonnement'),
          ),
          const SizedBox(height: 24),
          Card(
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(Icons.settings_outlined),
                  title: const Text('Paramètres'),
                  subtitle: const Text('Réseau, DNS, proxy, diagnostic'),
                  onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const SettingsScreen())),
                ),
                ListTile(
                  leading: const Icon(Icons.support_agent),
                  title: const Text('Assistance'),
                  onTap: () => _openSupport(context),
                ),
                ListTile(
                  leading: const Icon(Icons.privacy_tip_outlined),
                  title: const Text('Politique de confidentialité'),
                  onTap: () => _openLegal(context, LegalPage.privacy),
                ),
                ListTile(
                  leading: const Icon(Icons.description_outlined),
                  title: const Text("Conditions d'utilisation"),
                  onTap: () => _openLegal(context, LegalPage.terms),
                ),
                ListTile(
                  leading: const Icon(Icons.info_outline),
                  title: const Text('À propos'),
                  onTap: () => _openLegal(context, LegalPage.about),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
