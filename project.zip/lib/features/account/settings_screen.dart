import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../app/constants.dart';
import '../../services/network_settings.dart';
import '../../services/subscription_store.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late final TextEditingController _doh;
  late final TextEditingController _host;
  late final TextEditingController _port;
  late final TextEditingController _agent;
  late final TextEditingController _connect;
  late final TextEditingController _receive;
  late final TextEditingController _address;
  bool _diagnosing = false;
  List<DiagnosticStep>? _steps;

  @override
  void initState() {
    super.initState();
    final n = context.read<NetworkSettings>();
    final sub = context.read<SubscriptionStore>().active;
    _doh = TextEditingController(text: n.customDoh);
    _host = TextEditingController(text: n.proxyHost);
    _port = TextEditingController(text: '${n.proxyPort}');
    _agent = TextEditingController(text: n.userAgent);
    _connect = TextEditingController(text: '${n.connectTimeoutSec}');
    _receive = TextEditingController(text: '${n.receiveTimeoutSec}');
    _address = TextEditingController(text: sub?.url ?? '');
  }

  @override
  void dispose() {
    for (final c in [_doh, _host, _port, _agent, _connect, _receive, _address]) {
      c.dispose();
    }
    super.dispose();
  }

  String _dnsLabel(DnsMode m) {
    switch (m) {
      case DnsMode.off:
        return 'Désactivé';
      case DnsMode.cloudflare:
        return 'Cloudflare';
      case DnsMode.google:
        return 'Google';
      case DnsMode.quad9:
        return 'Quad9';
      case DnsMode.custom:
        return 'Personnalisé';
    }
  }

  String _proxyLabel(ProxyType t) {
    switch (t) {
      case ProxyType.http:
        return 'HTTP';
      case ProxyType.https:
        return 'HTTPS';
      case ProxyType.socks:
        return 'SOCKS';
    }
  }

  Future<void> _addHeader(NetworkSettings n) async {
    final controller = TextEditingController();
    final value = await showDialog<String>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Ajouter un en-tête'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(hintText: 'Nom: valeur'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(c).pop(), child: const Text('Annuler')),
          FilledButton(onPressed: () => Navigator.of(c).pop(controller.text.trim()), child: const Text('Ajouter')),
        ],
      ),
    );
    controller.dispose();
    if (value != null && value.contains(':')) {
      await n.update(() => n.customHeaders = [...n.customHeaders, value]);
    }
  }

  Future<void> _diagnose(NetworkSettings n) async {
    if (_address.text.trim().isEmpty) return;
    setState(() {
      _diagnosing = true;
      _steps = null;
    });
    final steps = await n.diagnose(_address.text);
    if (mounted) {
      setState(() {
        _steps = steps;
        _diagnosing = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final n = context.watch<NetworkSettings>();
    final theme = Theme.of(context);
    final steps = _steps;
    final failed = steps != null && steps.any((s) => !s.ok);

    Widget title(String text) => Padding(
          padding: const EdgeInsets.only(top: 24, bottom: 8),
          child: Text(text, style: theme.textTheme.titleMedium?.copyWith(color: theme.colorScheme.primary)),
        );

    return Scaffold(
      appBar: AppBar(title: const Text('Paramètres · Réseau')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          title('DNS sécurisé'),
          DropdownButtonFormField<DnsMode>(
            initialValue: n.dnsMode,
            decoration: const InputDecoration(labelText: 'Fournisseur'),
            items: [for (final m in DnsMode.values) DropdownMenuItem(value: m, child: Text(_dnsLabel(m)))],
            onChanged: (m) {
              if (m != null) n.update(() => n.dnsMode = m);
            },
          ),
          if (n.dnsMode == DnsMode.custom) ...[
            const SizedBox(height: 12),
            TextField(
              controller: _doh,
              keyboardType: TextInputType.url,
              decoration: const InputDecoration(labelText: 'URL DoH (https://…)'),
              onChanged: (v) => n.update(() => n.customDoh = v.trim()),
            ),
          ],
          const SizedBox(height: 8),
          const Text(
            "Le DNS sécurisé s'applique au chargement des listes. En cas d'échec, le DNS du système est utilisé.",
            style: TextStyle(fontSize: 12, color: Colors.white54),
          ),
          title('Proxy'),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Utiliser un proxy'),
            value: n.proxyEnabled,
            onChanged: (v) => n.update(() => n.proxyEnabled = v),
          ),
          if (n.proxyEnabled) ...[
            DropdownButtonFormField<ProxyType>(
              initialValue: n.proxyType,
              decoration: const InputDecoration(labelText: 'Type'),
              items: [for (final t in ProxyType.values) DropdownMenuItem(value: t, child: Text(_proxyLabel(t)))],
              onChanged: (t) {
                if (t != null) n.update(() => n.proxyType = t);
              },
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _host,
              decoration: const InputDecoration(labelText: 'Hôte'),
              onChanged: (v) => n.update(() => n.proxyHost = v.trim()),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _port,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Port'),
              onChanged: (v) {
                final p = int.tryParse(v);
                if (p != null && p > 0 && p < 65536) n.update(() => n.proxyPort = p);
              },
            ),
            if (n.proxyType == ProxyType.socks)
              const Padding(
                padding: EdgeInsets.only(top: 8),
                child: Text(
                  "SOCKS n'est pas encore appliqué aux téléchargements dans cette version.",
                  style: TextStyle(fontSize: 12, color: Colors.orangeAccent),
                ),
              ),
          ],
          title('User-Agent'),
          TextField(
            controller: _agent,
            decoration: const InputDecoration(labelText: 'User-Agent'),
            onChanged: (v) => n.update(() => n.userAgent = v.trim().isEmpty ? AppConstants.defaultUserAgent : v.trim()),
          ),
          title('En-têtes personnalisés'),
          for (final h in n.customHeaders)
            ListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(h),
              trailing: IconButton(
                tooltip: 'Supprimer',
                icon: const Icon(Icons.delete_outline),
                onPressed: () => n.update(() => n.customHeaders = [...n.customHeaders]..remove(h)),
              ),
            ),
          OutlinedButton.icon(
            onPressed: () => _addHeader(n),
            icon: const Icon(Icons.add),
            label: const Text('Ajouter un en-tête'),
          ),
          title('Délais (secondes)'),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _connect,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'Connexion'),
                  onChanged: (v) {
                    final s = int.tryParse(v);
                    if (s != null && s > 0) n.update(() => n.connectTimeoutSec = s);
                  },
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: TextField(
                  controller: _receive,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'Réponse'),
                  onChanged: (v) {
                    final s = int.tryParse(v);
                    if (s != null && s > 0) n.update(() => n.receiveTimeoutSec = s);
                  },
                ),
              ),
            ],
          ),
          title('Diagnostic'),
          TextField(
            controller: _address,
            keyboardType: TextInputType.url,
            decoration: const InputDecoration(labelText: 'Adresse du serveur à tester'),
          ),
          const SizedBox(height: 12),
          FilledButton(
            onPressed: _diagnosing ? null : () => _diagnose(n),
            child: _diagnosing
                ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                : const Text('Diagnostiquer'),
          ),
          if (steps != null) ...[
            const SizedBox(height: 12),
            for (final s in steps)
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: Icon(s.ok ? Icons.check_circle : Icons.error, color: s.ok ? Colors.green : Colors.redAccent),
                title: Text(s.label),
                subtitle: Text(s.detail),
              ),
            if (failed)
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.redAccent.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Text(AppConstants.blockedHint),
              )
            else
              const Text('Tous les tests ont réussi.'),
          ],
          const SizedBox(height: 32),
        ],
      ),
    );
  }
}
