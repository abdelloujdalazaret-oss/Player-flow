import 'dart:async';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../app/routes.dart';
import '../../services/subscription_store.dart';
import '../account/add_subscription_screen.dart';

class IntroScreen extends StatefulWidget {
  const IntroScreen({super.key});

  @override
  State<IntroScreen> createState() => _IntroScreenState();
}

class _IntroScreenState extends State<IntroScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _controller =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 1400));
  late final Animation<double> _fade = CurvedAnimation(parent: _controller, curve: Curves.easeOut);
  late final Animation<double> _scale = Tween<double>(begin: 0.8, end: 1).animate(
    CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic),
  );
  final AudioPlayer _audio = AudioPlayer();
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _controller.forward();
    _playSound();
    _timer = Timer(const Duration(milliseconds: 2800), _next);
  }

  Future<void> _playSound() async {
    try {
      await _audio.play(AssetSource('sounds/intro.mp3'));
    } catch (_) {
      // Le son est facultatif : l'intro continue sans lui.
    }
  }

  void _next() {
    if (!mounted) return;
    final hasSubscription = context.read<SubscriptionStore>().subscriptions.isNotEmpty;
    if (hasSubscription) {
      Navigator.of(context).pushReplacementNamed(AppRoutes.home);
    } else {
      Navigator.of(context).pushReplacementNamed(
        AppRoutes.addSubscription,
        arguments: const AddSubscriptionArgs(firstRun: true),
      );
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    _controller.dispose();
    _audio.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: FadeTransition(
          opacity: _fade,
          child: ScaleTransition(
            scale: _scale,
            child: Image.asset('assets/images/logo.png', width: 220, height: 220),
          ),
        ),
      ),
    );
  }
}
