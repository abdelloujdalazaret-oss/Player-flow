class ChannelCategory {
  const ChannelCategory({required this.name, required this.count});

  final String name;
  final int count;
}
