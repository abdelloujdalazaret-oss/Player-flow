enum SubscriptionType { m3u, xtream }

class Subscription {
  const Subscription({
    required this.id,
    required this.name,
    required this.type,
    required this.url,
    this.username = '',
    this.password = '',
    this.status = 'Non vérifié',
  });

  final String id;
  final String name;
  final SubscriptionType type;

  /// URL de la playlist M3U, ou adresse du serveur pour Xtream Codes.
  final String url;
  final String username;
  final String password;
  final String status;

  String get typeLabel => type == SubscriptionType.m3u ? 'M3U' : 'Xtream Codes';

  Subscription copyWith({String? name, String? url, String? username, String? password, String? status}) {
    return Subscription(
      id: id,
      name: name ?? this.name,
      type: type,
      url: url ?? this.url,
      username: username ?? this.username,
      password: password ?? this.password,
      status: status ?? this.status,
    );
  }

  /// Données non sensibles (SharedPreferences).
  Map<String, dynamic> toPublicJson() => {
        'id': id,
        'name': name,
        'type': type.name,
        'status': status,
      };

  /// Données sensibles (stockage sécurisé).
  Map<String, dynamic> toSecretJson() => {
        'url': url,
        'username': username,
        'password': password,
      };

  factory Subscription.fromJson(Map<String, dynamic> pub, Map<String, dynamic> secret) {
    return Subscription(
      id: pub['id'] as String,
      name: (pub['name'] ?? '') as String,
      type: SubscriptionType.values.firstWhere(
        (t) => t.name == pub['type'],
        orElse: () => SubscriptionType.m3u,
      ),
      status: (pub['status'] ?? 'Non vérifié') as String,
      url: (secret['url'] ?? '') as String,
      username: (secret['username'] ?? '') as String,
      password: (secret['password'] ?? '') as String,
    );
  }
}
