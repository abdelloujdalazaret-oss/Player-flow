enum ContentType { live, movie, series }

class Channel {
  const Channel({
    required this.name,
    required this.url,
    required this.group,
    required this.type,
    this.logo,
    this.userAgent,
    this.tvgId,
    this.seriesId,
  });

  final String name;
  final String url;
  final String group;
  final ContentType type;
  final String? logo;
  final String? userAgent;
  final String? tvgId;

  /// Renseigné uniquement pour les séries Xtream (les épisodes sont chargés à la demande).
  final String? seriesId;

  bool get isSeriesContainer => seriesId != null;

  String get key => seriesId != null ? 'series:$seriesId' : url;

  Map<String, dynamic> toJson() => {
        'name': name,
        'url': url,
        'group': group,
        'type': type.name,
        'logo': logo,
        'userAgent': userAgent,
        'tvgId': tvgId,
        'seriesId': seriesId,
      };

  factory Channel.fromJson(Map<String, dynamic> json) => Channel(
        name: (json['name'] ?? '') as String,
        url: (json['url'] ?? '') as String,
        group: (json['group'] ?? '') as String,
        type: ContentType.values.firstWhere(
          (t) => t.name == json['type'],
          orElse: () => ContentType.live,
        ),
        logo: json['logo'] as String?,
        userAgent: json['userAgent'] as String?,
        tvgId: json['tvgId'] as String?,
        seriesId: json['seriesId'] as String?,
      );
}
