class AppConstants {
  static const String appName = 'Player Flow';
  static const String version = '1.0.0';
  static const String description =
      'Lecteur IPTV moderne pour gérer et lire vos propres sources légales (M3U et Xtream Codes).';
  static const String defaultUserAgent = 'VLC/3.0.18 LibVLC/3.0.18';

  /// Coordonnées d'assistance : à renseigner avant publication.
  /// Email, par exemple : support@exemple.com
  static const String supportEmail = '';

  /// Numéro WhatsApp au format international, sans « + » ni espaces.
  static const String supportWhatsapp = '';

  static const String legalNotice =
      'Player Flow ne fournit aucun abonnement IPTV, aucune playlist et aucun contenu audiovisuel. '
      "L'utilisateur est responsable des sources qu'il ajoute et doit utiliser uniquement des contenus "
      'et services pour lesquels il dispose des droits nécessaires.';

  static const String blockedHint =
      'Votre opérateur peut bloquer ce serveur. Essayez un DNS sécurisé, un proxy ou un VPN.';
}
