import 'package:flutter/material.dart';

import '../features/account/add_subscription_screen.dart';
import '../features/home/home_screen.dart';
import '../features/intro/intro_screen.dart';
import '../features/player/player_screen.dart';

class AppRoutes {
  static const String intro = '/';
  static const String home = '/home';
  static const String addSubscription = '/add';
  static const String player = '/player';

  static Route<void> onGenerate(RouteSettings settings) {
    switch (settings.name) {
      case home:
        return MaterialPageRoute<void>(settings: settings, builder: (_) => const HomeScreen());
      case addSubscription:
        final args = settings.arguments as AddSubscriptionArgs? ?? const AddSubscriptionArgs();
        return MaterialPageRoute<void>(
          settings: settings,
          builder: (_) => AddSubscriptionScreen(args: args),
        );
      case player:
        final args = settings.arguments! as PlayerArgs;
        return MaterialPageRoute<void>(settings: settings, builder: (_) => PlayerScreen(args: args));
      case intro:
      default:
        return MaterialPageRoute<void>(settings: settings, builder: (_) => const IntroScreen());
    }
  }
}
