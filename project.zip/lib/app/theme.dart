import 'package:flutter/material.dart';

class AppColors {
  static const Color background = Color(0xFF071426);
  static const Color field = Color(0xFF10294A);
  static const Color accent = Color(0xFF22D3EE);
}

const double kRadius = 12;

ThemeData buildTheme() {
  final scheme = ColorScheme.fromSeed(
    seedColor: AppColors.accent,
    brightness: Brightness.dark,
  ).copyWith(
    primary: AppColors.accent,
    onPrimary: Colors.black,
    surface: AppColors.background,
    surfaceContainerHighest: AppColors.field,
  );
  final shape = RoundedRectangleBorder(borderRadius: BorderRadius.circular(kRadius));
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: AppColors.background,
    focusColor: AppColors.accent.withValues(alpha: 0.35),
    hoverColor: AppColors.accent.withValues(alpha: 0.15),
    listTileTheme: ListTileThemeData(shape: shape),
    appBarTheme: const AppBarTheme(
      backgroundColor: AppColors.background,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
    ),
    cardTheme: CardThemeData(
      color: AppColors.field,
      elevation: 0,
      margin: EdgeInsets.zero,
      shape: shape,
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: AppColors.field,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(kRadius),
        borderSide: BorderSide.none,
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(kRadius),
        borderSide: const BorderSide(color: AppColors.accent, width: 2.5),
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 18),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(shape: shape, minimumSize: const Size(64, 48)),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(shape: shape, minimumSize: const Size(64, 48)),
    ),
    navigationBarTheme: const NavigationBarThemeData(
      backgroundColor: AppColors.field,
      indicatorColor: Color(0x3322D3EE),
    ),
    chipTheme: ChipThemeData(shape: shape, side: BorderSide.none),
    bottomSheetTheme: const BottomSheetThemeData(
      backgroundColor: AppColors.field,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(kRadius)),
      ),
    ),
    dialogTheme: DialogThemeData(backgroundColor: AppColors.field, shape: shape),
  );
}
