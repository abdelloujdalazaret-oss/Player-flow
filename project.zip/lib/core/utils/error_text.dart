import 'dart:async';
import 'dart:io';

class AppException implements Exception {
  const AppException(this.message);

  final String message;

  @override
  String toString() => message;
}

/// Convertit une erreur technique en message compréhensible, en français.
String frenchError(Object error) {
  if (error is AppException) return error.message;
  if (error is TimeoutException) {
    return "Délai dépassé : le serveur n'a pas répondu à temps.";
  }
  if (error is HandshakeException || error is TlsException) {
    return 'Connexion sécurisée impossible (certificat ou protocole HTTPS refusé).';
  }
  if (error is SocketException) {
    return 'Impossible de joindre le serveur. Vérifiez votre connexion et l’adresse saisie.';
  }
  if (error is HttpException) {
    return 'Erreur réseau : ${error.message}';
  }
  if (error is FormatException) {
    return 'Réponse du serveur invalide ou illisible.';
  }
  return 'Une erreur est survenue. Veuillez réessayer.';
}
