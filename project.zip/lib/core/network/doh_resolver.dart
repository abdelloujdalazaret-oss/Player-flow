import 'dart:convert';
import 'dart:io';

/// Résolution DNS over HTTPS (format JSON). Renvoie null en cas d'échec afin
/// que l'appelant puisse se replier sur le DNS système.
class DohResolver {
  DohResolver(this.endpoint);

  final String endpoint;
  final Map<String, ({String ip, DateTime expires})> _cache = {};

  Future<String?> resolve(String host) async {
    if (InternetAddress.tryParse(host) != null) return host;
    final cached = _cache[host];
    if (cached != null && cached.expires.isAfter(DateTime.now())) return cached.ip;

    final client = HttpClient()..connectionTimeout = const Duration(seconds: 5);
    try {
      final uri = Uri.parse(endpoint).replace(queryParameters: {'name': host, 'type': 'A'});
      final request = await client.getUrl(uri).timeout(const Duration(seconds: 6));
      request.headers.set(HttpHeaders.acceptHeader, 'application/dns-json');
      final response = await request.close().timeout(const Duration(seconds: 6));
      if (response.statusCode != 200) return null;
      final body = await utf8.decodeStream(response).timeout(const Duration(seconds: 6));
      final json = jsonDecode(body);
      if (json is! Map) return null;
      final answers = json['Answer'];
      if (answers is! List) return null;
      for (final a in answers) {
        if (a is Map && a['type'] == 1 && a['data'] is String) {
          final ip = a['data'] as String;
          if (InternetAddress.tryParse(ip) != null) {
            _cache[host] = (ip: ip, expires: DateTime.now().add(const Duration(minutes: 5)));
            return ip;
          }
        }
      }
      return null;
    } catch (_) {
      return null;
    } finally {
      client.close(force: true);
    }
  }
}
