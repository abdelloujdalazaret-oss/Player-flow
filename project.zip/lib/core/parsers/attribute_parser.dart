final RegExp _attributeRe = RegExp(
  r'''([\w\-.]+)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s,"']+))''',
);

/// Extrait les attributs `clé="valeur"` d'une ligne #EXTINF (clés en minuscules).
Map<String, String> parseExtinfAttributes(String header) {
  final result = <String, String>{};
  for (final m in _attributeRe.allMatches(header)) {
    final value = m.group(2) ?? m.group(3) ?? m.group(4) ?? '';
    result[m.group(1)!.toLowerCase()] = value.trim();
  }
  return result;
}

/// Sépare le contenu d'un #EXTINF (après les deux-points) en en-tête et titre.
/// La première virgule située hors guillemets sépare les deux.
({String header, String title}) splitExtinf(String body) {
  var inQuote = false;
  var quoteChar = '';
  for (var i = 0; i < body.length; i++) {
    final c = body[i];
    if (inQuote) {
      if (c == quoteChar) inQuote = false;
    } else if (c == '"' || c == "'") {
      // Une apostrophe isolée dans un titre ne doit pas ouvrir de guillemet :
      // on ne la considère que si elle suit un « = ».
      if (c == '"' || (i > 0 && body[i - 1] == '=')) {
        inQuote = true;
        quoteChar = c;
      }
    } else if (c == ',') {
      return (header: body.substring(0, i), title: body.substring(i + 1).trim());
    }
  }
  if (inQuote) {
    // Guillemet jamais fermé : on se rabat sur la dernière virgule.
    final last = body.lastIndexOf(',');
    if (last >= 0) {
      return (header: body.substring(0, last), title: body.substring(last + 1).trim());
    }
  }
  return (header: body, title: '');
}
