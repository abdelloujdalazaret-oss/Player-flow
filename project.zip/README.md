# Player Flow

## 1. Présentation

Player Flow est une application Android IPTV (Flutter) qui permet de gérer et de lire **vos propres** sources IPTV légales : playlists M3U et comptes Xtream Codes. L'application ne fournit aucun abonnement, aucune playlist et aucun contenu. Toute l'interface est en français.

## 2. Prérequis

- Flutter 3.35 ou plus récent (Dart 3.5+)
- Android SDK et JDK 17
- Un appareil ou un émulateur Android (API 21 minimum)

## 3. Installation Flutter

Suivez le guide officiel : https://docs.flutter.dev/get-started/install puis vérifiez avec :

```
flutter doctor
```

## 4. Installation des dépendances

```
flutter pub get
```

## 5. Lancement

```
flutter run
```

## 6. Analyse

```
flutter analyze
```

## 7. Tests

```
flutter test
```

## 8. Nettoyage

```
flutter clean
```

## 9. Build APK

```
flutter build apk --release
```

## 10. Emplacement de l'APK

```
build/app/outputs/flutter-apk/app-release.apk
```

Le workflow GitHub Actions `.github/workflows/build.yml` exécute l'analyse, les tests et le build, puis publie l'APK comme artefact (onglet *Actions* du dépôt).

## 11. Dépannage

- **`flutter.sdk not set in local.properties`** : lancez `flutter pub get` à la racine, ce qui génère `android/local.properties`.
- **Échec de R8 / minification** : dans `android/app/build.gradle.kts`, mettez `isMinifyEnabled = false` et `isShrinkResources = false`, puis relancez le build.
- **Version de Gradle ou du plugin Android** : utilisez Flutter 3.35 (versions de Gradle et d'AGP alignées). Avec une autre version de Flutter, adaptez `android/settings.gradle.kts` et `gradle-wrapper.properties`.
- **Chaînes qui ne se chargent pas** : ouvrez *Compte → Paramètres → Diagnostiquer* pour tester le DNS, la connexion TCP et HTTP. Un opérateur peut bloquer certains serveurs : essayez un DNS sécurisé, un proxy ou un VPN.
- **Pas de son à l'introduction** : vérifiez que `assets/sounds/intro.mp3` existe et que le volume du téléphone est activé.

## 12. Configuration des assets

- `assets/images/logo.png` : logo affiché à l'introduction et à l'écran de démarrage.
- `assets/images/icon.png` et `assets/images/icon_foreground.png` : sources de l'icône (les ressources Android sont déjà générées dans `android/app/src/main/res`).
- `assets/sounds/intro.mp3` : son d'introduction.

Régénération facultative de l'icône et du splash :

```
dart run flutter_launcher_icons
dart run flutter_native_splash:create
```

## 13. Configuration Android

- Nom : Player Flow, identifiant `com.playerflow.app`, `minSdk 21`.
- Permissions : `INTERNET`, `ACCESS_NETWORK_STATE`, `WAKE_LOCK`.
- Trafic HTTP autorisé (`usesCleartextTraffic` et `network_security_config.xml`).
- R8/ProGuard : règles dans `android/app/proguard-rules.pro` (media_kit conservé).
- La version release est signée avec la clé de debug : remplacez-la par votre keystore avant toute publication.
- Assistance : renseignez `supportEmail` et `supportWhatsapp` dans `lib/app/constants.dart`.

## 14. Informations légales

Player Flow ne fournit aucun abonnement IPTV, aucune playlist et aucun contenu audiovisuel. L'utilisateur est responsable des sources qu'il ajoute et doit utiliser uniquement des contenus et services pour lesquels il dispose des droits nécessaires.

## Limites connues de cette version

- Le Picture-in-Picture n'est pas implémenté.
- Le proxy SOCKS est configurable mais n'est pas appliqué aux téléchargements ; les proxys HTTP/HTTPS le sont. Le lecteur vidéo n'utilise pas le proxy ni le DoH.
- La navigation à la télécommande (Android TV) n'est pas optimisée.
