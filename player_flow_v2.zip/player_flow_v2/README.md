# Player Flow — تطبيق IPTV (Flutter)

واجهة حديثة داكنة بالفرنسية، بدون أي تشفير للملف أو للكود.

## محتوى المشروع
- `lib/` الكود (انترو، إضافة اشتراك M3U/Xtream، القنوات، المشغّل، الحساب، سياسة الخصوصية، الشروط، الدعم، حول)
- `assets/` الأيقونات: `icon.png` (أيقونة التطبيق) · `icon_fg.png` (أيقونة متكيفة) · `intro_logo.png` (شعار المقدمة)
- `.github/workflows/main.yml` يبني الـ APK تلقائيًا على GitHub

## بناء الـ APK بدون كمبيوتر (GitHub)
1. فك الضغط وارفع **كل** الملفات إلى جذر المستودع، ومنها المجلد المخفي `.github`.
   (إن لم يظهر المجلد: أنشئ ملفًا باسم `.github/workflows/main.yml` وانسخ محتواه.)
2. تبويب **Actions** ثم **Build APK** ثم **Run workflow**، وانتظر ✅.
3. تبويب **Releases** ثم حمّل `PlayerFlow.apk` مباشرة.
4. إن فشل رفع Release: Settings ثم Actions ثم General ثم Workflow permissions ثم Read and write.

## على كمبيوتر
```
flutter create --platforms=android .
flutter pub get
dart run flutter_launcher_icons
flutter build apk --release
```
(أضف يدويًا في AndroidManifest: صلاحية INTERNET و `android:usesCleartextTraffic="true"`.)

## تعديل جهات الدعم
في `lib/theme.dart` غيّر `kSupportEmail` و `kSupportWhatsapp`، أو من التطبيق: الحساب ثم Assistance ثم Modifier les contacts.
