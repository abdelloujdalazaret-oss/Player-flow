import 'package:flutter/material.dart';
import 'add_sub_page.dart';
import 'home_page.dart';
import 'models.dart';
import 'theme.dart';

/// Intro 2,5 s : logo animé (fade + scale), puis accueil ou « Ajouter un abonnement ».
class IntroPage extends StatefulWidget {
  const IntroPage({super.key});
  @override
  State<IntroPage> createState() => _IntroPageState();
}

class _IntroPageState extends State<IntroPage> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 1400))..forward();

  @override
  void initState() {
    super.initState();
    _go();
  }

  Future<void> _go() async {
    await Future.delayed(const Duration(milliseconds: 2600));
    final subs = await Store.subs();
    if (!mounted) return;
    Navigator.pushReplacement(
      context,
      PageRouteBuilder<void>(
        transitionDuration: const Duration(milliseconds: 400),
        pageBuilder: (_, __, ___) => subs.isEmpty ? const AddSubPage(first: true) : const HomePage(),
        transitionsBuilder: (_, a, __, child) => FadeTransition(opacity: a, child: child),
      ),
    );
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment(0, -.2),
            radius: 1.0,
            colors: [Color(0xFF12304A), kBg],
          ),
        ),
        child: Center(
          child: FadeTransition(
            opacity: _c,
            child: ScaleTransition(
              scale: Tween<double>(begin: .7, end: 1).animate(CurvedAnimation(parent: _c, curve: Curves.easeOutBack)),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Container(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    boxShadow: [BoxShadow(color: kAccent.withAlpha(90), blurRadius: 50, spreadRadius: 4)],
                  ),
                  child: ClipOval(
                    child: Image.asset('assets/intro_logo.png', width: 180, height: 180,
                        errorBuilder: (_, __, ___) => const Icon(Icons.live_tv, size: 120, color: kAccent)),
                  ),
                ),
                const SizedBox(height: 24),
                const Text(kAppName, style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800, letterSpacing: 1)),
                const SizedBox(height: 6),
                const Text('Votre lecteur IPTV', style: TextStyle(color: Colors.white54)),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}
