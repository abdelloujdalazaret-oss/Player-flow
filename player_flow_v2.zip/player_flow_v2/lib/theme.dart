import 'package:flutter/material.dart';

const kAppName = 'Player Flow';
const kVersion = '1.0.0';
const kAccent = Color(0xFF14B8A6);
const kBg = Color(0xFF0E131C);
const kField = Color(0xFF182131);
const kUA = 'VLC/3.0.18 LibVLC/3.0.18';
const kHint = 'Votre opérateur peut bloquer ce serveur. Essayez un DNS sécurisé, un proxy ou un VPN.';

// Contacts d'assistance par défaut. Modifiables aussi dans l'app : Compte > Assistance.
const kSupportEmail = '';
const kSupportWhatsapp = ''; // avec indicatif, sans + (ex : 212600000000)

ThemeData buildTheme() {
  return ThemeData(
    useMaterial3: true,
    colorScheme: ColorScheme.fromSeed(seedColor: kAccent, brightness: Brightness.dark),
    scaffoldBackgroundColor: kBg,
    appBarTheme: const AppBarTheme(backgroundColor: kBg, elevation: 0, scrolledUnderElevation: 0),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: kField,
      indicatorColor: kAccent.withAlpha(60),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: kField,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        minimumSize: const Size(48, 50),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        minimumSize: const Size(48, 50),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
    ),
  );
}

BoxDecoration cardDeco({bool selected = false}) => BoxDecoration(
      color: kField,
      borderRadius: BorderRadius.circular(16),
      border: Border.all(color: selected ? kAccent : Colors.white10, width: selected ? 1.5 : 1),
    );
