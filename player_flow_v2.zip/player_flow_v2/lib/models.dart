import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'theme.dart';

/// Une chaîne / un film / un épisode.
class Ch {
  const Ch(this.name, this.url, this.group, this.logo);
  final String name, url, group;
  final String? logo;

  /// 0 = Direct, 1 = Films, 2 = Séries (détection par l'URL).
  int get kind => url.contains('/movie/') ? 1 : (url.contains('/series/') ? 2 : 0);
}

/// Un abonnement (lien M3U ; Xtream est converti en lien M3U).
class Sub {
  Sub(this.name, this.url);
  final String name, url;
  Map<String, String> toJson() => {'name': name, 'url': url};
  factory Sub.fromJson(Map<String, dynamic> j) => Sub('${j['name']}', '${j['url']}');
}

/// Parseur M3U tolérant (BOM, #EXTGRP, tvg-logo, group-title...).
/// Fonction de premier niveau : utilisable avec compute() (hors thread UI).
List<Ch> parseM3u(String raw) {
  final text = raw.startsWith('\uFEFF') ? raw.substring(1) : raw;
  final out = <Ch>[];
  final attr = RegExp(r'([\w-]+)="([^"]*)"');
  const def = 'Sans catégorie';
  String name = '';
  String group = def;
  String? logo;
  for (final l in text.split(RegExp(r'\r?\n'))) {
    final line = l.trim();
    if (line.isEmpty) continue;
    if (line.startsWith('#EXTINF')) {
      var end = 0;
      final a = <String, String>{};
      for (final m in attr.allMatches(line)) {
        a[m.group(1)!.toLowerCase()] = m.group(2)!;
        end = m.end;
      }
      final c = line.indexOf(',', end);
      name = c >= 0 ? line.substring(c + 1).trim() : (a['tvg-name'] ?? '');
      final g = (a['group-title'] ?? '').trim();
      group = g.isEmpty ? def : g;
      logo = a['tvg-logo'];
    } else if (line.startsWith('#EXTGRP:')) {
      if (group == def) group = line.substring(8).trim();
    } else if (line.startsWith('#')) {
      continue;
    } else if (line.contains('://')) {
      out.add(Ch(name.isEmpty ? 'Sans nom' : name, line, group, (logo == null || logo.isEmpty) ? null : logo));
      name = '';
      group = def;
      logo = null;
    }
  }
  return out;
}

/// Stockage local (SharedPreferences) : abonnements, favoris, contacts.
class Store {
  static Future<List<Sub>> subs() async {
    final p = await SharedPreferences.getInstance();
    return (p.getStringList('subs') ?? []).map((e) => Sub.fromJson(jsonDecode(e) as Map<String, dynamic>)).toList();
  }

  static Future<void> saveSubs(List<Sub> l) async {
    final p = await SharedPreferences.getInstance();
    await p.setStringList('subs', l.map((e) => jsonEncode(e.toJson())).toList());
  }

  static Future<int> active() async {
    final p = await SharedPreferences.getInstance();
    return p.getInt('active') ?? 0;
  }

  static Future<void> setActive(int i) async {
    final p = await SharedPreferences.getInstance();
    await p.setInt('active', i);
  }

  static Future<Set<String>> favs() async {
    final p = await SharedPreferences.getInstance();
    return (p.getStringList('favs') ?? []).toSet();
  }

  static Future<void> saveFavs(Set<String> s) async {
    final p = await SharedPreferences.getInstance();
    await p.setStringList('favs', s.toList());
  }

  /// [e-mail, whatsapp]
  static Future<List<String>> support() async {
    final p = await SharedPreferences.getInstance();
    return [p.getString('sup_email') ?? kSupportEmail, p.getString('sup_wa') ?? kSupportWhatsapp];
  }

  static Future<void> saveSupport(String email, String wa) async {
    final p = await SharedPreferences.getInstance();
    await p.setString('sup_email', email);
    await p.setString('sup_wa', wa);
  }
}
