import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'account_page.dart';
import 'add_sub_page.dart';
import 'models.dart';
import 'player_page.dart';
import 'theme.dart';

/// Accueil : onglets « Chaînes » et « Compte ».
class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<Sub> subs = [];
  int active = 0;
  List<Ch> all = [];
  Set<String> favs = {};
  bool loading = true, grid = false, ready = false;
  String? error;
  int tab = 0;
  int kind = 0;
  String cat = 'all', q = '';
  Timer? _deb;
  final _search = TextEditingController();

  @override
  void initState() {
    super.initState();
    _init();
  }

  @override
  void dispose() {
    _deb?.cancel();
    _search.dispose();
    super.dispose();
  }

  Future<void> _init() async {
    subs = await Store.subs();
    active = await Store.active();
    favs = await Store.favs();
    if (subs.isEmpty) {
      if (mounted) {
        Navigator.pushReplacement(context, MaterialPageRoute<void>(builder: (_) => const AddSubPage(first: true)));
      }
      return;
    }
    if (active >= subs.length) active = 0;
    ready = true;
    await _load();
  }

  Future<void> _load() async {
    setState(() {
      loading = true;
      error = null;
      all = [];
    });
    try {
      final r = await http
          .get(Uri.parse(subs[active].url), headers: {'User-Agent': kUA}).timeout(const Duration(seconds: 90));
      if (r.statusCode >= 400) throw 'HTTP ${r.statusCode}';
      final list = await compute(parseM3u, utf8.decode(r.bodyBytes, allowMalformed: true));
      if (list.isEmpty) throw 'liste vide';
      all = list;
    } catch (e) {
      error = 'Échec du chargement ($e).\n$kHint';
    }
    if (mounted) setState(() => loading = false);
  }

  Future<void> _select(int i) async {
    active = i;
    await Store.setActive(i);
    cat = 'all';
    setState(() => tab = 0);
    await _load();
  }

  Future<void> _delete(int i) async {
    subs.removeAt(i);
    await Store.saveSubs(subs);
    if (!mounted) return;
    if (subs.isEmpty) {
      Navigator.pushReplacement(context, MaterialPageRoute<void>(builder: (_) => const AddSubPage(first: true)));
      return;
    }
    active = 0;
    await Store.setActive(0);
    cat = 'all';
    await _load();
  }

  Widget _logo(Ch c) => c.logo == null
      ? const Icon(Icons.tv, color: Colors.white38)
      : Image.network(c.logo!, fit: BoxFit.contain, errorBuilder: (_, __, ___) => const Icon(Icons.tv, color: Colors.white38));

  Widget _heart(Ch c, bool fav) => IconButton(
        visualDensity: VisualDensity.compact,
        icon: Icon(fav ? Icons.favorite : Icons.favorite_border, size: 20, color: fav ? Colors.redAccent : Colors.white54),
        onPressed: () async {
          if (fav) {
            favs.remove(c.url);
          } else {
            favs.add(c.url);
          }
          setState(() {});
          await Store.saveFavs(favs);
        },
      );

  Widget _tile(List<Ch> shown, int i) {
    final c = shown[i];
    final fav = favs.contains(c.url);
    final title = Text(c.name, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13));
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: () => Navigator.push(
          context, MaterialPageRoute<void>(builder: (_) => PlayerPage(list: shown, index: i))),
      child: Container(
        decoration: cardDeco(),
        padding: const EdgeInsets.all(8),
        child: grid
            ? Column(children: [
                Expanded(child: _logo(c)),
                Row(children: [Expanded(child: title), _heart(c, fav)]),
              ])
            : Row(children: [
                SizedBox(width: 48, height: 48, child: _logo(c)),
                const SizedBox(width: 12),
                Expanded(child: title),
                _heart(c, fav),
              ]),
      ),
    );
  }

  Widget _cats(List<String> cats, double w) {
    final items = <MapEntry<String, String>>[
      const MapEntry('all', 'Toutes'),
      const MapEntry('fav', '♥ Favoris'),
      ...cats.map((e) => MapEntry(e, e)),
    ];
    return SizedBox(
      width: w,
      child: ListView.builder(
        itemCount: items.length,
        itemBuilder: (_, i) {
          final e = items[i];
          final sel = cat == e.key;
          return InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: () => setState(() => cat = e.key),
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
              decoration: BoxDecoration(
                color: sel ? kAccent.withAlpha(45) : null,
                borderRadius: BorderRadius.circular(14),
                border: sel ? Border.all(color: kAccent) : null,
              ),
              child: Text(e.value,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontWeight: sel ? FontWeight.w700 : FontWeight.w400, color: sel ? kAccent : null)),
            ),
          );
        },
      ),
    );
  }

  Widget _channels() {
    final landscape = MediaQuery.of(context).orientation == Orientation.landscape;
    final inKind = all.where((c) => c.kind == kind).toList();
    final cats = <String>[];
    final seen = <String>{};
    for (final c in inKind) {
      if (seen.add(c.group)) cats.add(c.group);
    }
    Iterable<Ch> list = cat == 'fav'
        ? inKind.where((c) => favs.contains(c.url))
        : (cat == 'all' ? inKind : inKind.where((c) => c.group == cat));
    if (q.isNotEmpty) {
      final s = q.toLowerCase();
      list = list.where((c) => c.name.toLowerCase().contains(s));
    }
    final shown = list.toList();

    Widget content;
    if (loading) {
      content = const Center(child: CircularProgressIndicator());
    } else if (error != null) {
      content = Center(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Icon(Icons.wifi_off, size: 44, color: Colors.white38),
            const SizedBox(height: 12),
            Text(error!, textAlign: TextAlign.center),
            const SizedBox(height: 12),
            FilledButton(onPressed: _load, child: const Text('Réessayer')),
          ]),
        ),
      );
    } else if (shown.isEmpty) {
      content = const Center(child: Text('Aucun élément'));
    } else if (grid) {
      content = GridView.builder(
        padding: const EdgeInsets.all(8),
        gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
            maxCrossAxisExtent: 160, mainAxisSpacing: 8, crossAxisSpacing: 8, childAspectRatio: .95),
        itemCount: shown.length,
        itemBuilder: (_, i) => _tile(shown, i),
      );
    } else {
      content = ListView.separated(
        padding: const EdgeInsets.all(8),
        itemCount: shown.length,
        separatorBuilder: (_, __) => const SizedBox(height: 6),
        itemBuilder: (_, i) => _tile(shown, i),
      );
    }

    return Column(children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(12, 4, 12, 8),
        child: SegmentedButton<int>(
          segments: const [
            ButtonSegment(value: 0, label: Text('Direct'), icon: Icon(Icons.live_tv, size: 18)),
            ButtonSegment(value: 1, label: Text('Films'), icon: Icon(Icons.movie_outlined, size: 18)),
            ButtonSegment(value: 2, label: Text('Séries'), icon: Icon(Icons.video_library_outlined, size: 18)),
          ],
          selected: {kind},
          onSelectionChanged: (s) => setState(() {
            kind = s.first;
            cat = 'all';
          }),
        ),
      ),
      Padding(
        padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
        child: Row(children: [
          Expanded(
            child: TextField(
              controller: _search,
              decoration: const InputDecoration(hintText: 'Rechercher…', prefixIcon: Icon(Icons.search), isDense: true),
              onChanged: (v) {
                _deb?.cancel();
                _deb = Timer(const Duration(milliseconds: 250), () {
                  if (mounted) setState(() => q = v.trim());
                });
              },
            ),
          ),
          IconButton(
            tooltip: 'Affichage',
            icon: Icon(grid ? Icons.view_list : Icons.grid_view),
            onPressed: () => setState(() => grid = !grid),
          ),
        ]),
      ),
      Expanded(
        child: Row(children: [
          _cats(cats, landscape ? 220 : 130),
          const VerticalDivider(width: 1),
          Expanded(child: content),
        ]),
      ),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    if (!ready) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    return Scaffold(
      appBar: tab == 0
          ? AppBar(
              title: Text(subs[active].name, maxLines: 1, overflow: TextOverflow.ellipsis),
              actions: [IconButton(tooltip: 'Actualiser', icon: const Icon(Icons.refresh), onPressed: _load)],
            )
          : AppBar(title: const Text('Compte')),
      body: SafeArea(
        top: false,
        child: tab == 0
            ? _channels()
            : AccountPage(
                subs: subs,
                active: active,
                onSelect: _select,
                onDelete: _delete,
                onAdd: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => const AddSubPage())),
              ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.live_tv_outlined), selectedIcon: Icon(Icons.live_tv), label: 'Chaînes'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Compte'),
        ],
      ),
    );
  }
}
