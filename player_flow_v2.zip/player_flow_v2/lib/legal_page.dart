import 'package:flutter/material.dart';
import 'theme.dart';

enum LegalKind { privacy, terms, about }

class LegalPage extends StatelessWidget {
  const LegalPage({super.key, required this.kind});
  final LegalKind kind;

  static const _privacy = [
    ('Résumé', 'Player Flow ne collecte aucune donnée personnelle et n\'envoie rien à ses développeurs. L\'application ne contient ni publicité, ni outil de mesure d\'audience, ni traceur.'),
    ('Données enregistrées sur votre appareil', 'Vos abonnements (liens M3U, serveur, identifiant et mot de passe Xtream), vos favoris et vos contacts d\'assistance sont enregistrés uniquement dans la mémoire locale de votre téléphone. Ils ne quittent pas votre appareil.'),
    ('Connexions réseau', 'L\'application se connecte directement aux serveurs que VOUS avez ajoutés pour charger la liste et lire les flux. Ces serveurs peuvent enregistrer votre adresse IP selon leur propre politique. Les logos des chaînes sont téléchargés depuis les adresses indiquées dans votre liste.'),
    ('Suppression', 'Vous pouvez supprimer un abonnement à tout moment depuis l\'onglet Compte. Désinstaller l\'application efface toutes les données.'),
    ('Contact', 'Pour toute question, utilisez Compte > Assistance.'),
  ];

  static const _terms = [
    ('1. Nature de l\'application', 'Player Flow est un lecteur multimédia. Il ne fournit, n\'héberge et ne vend aucun contenu, chaîne ou abonnement.'),
    ('2. Vos sources', 'Vous ajoutez vos propres sources (lien M3U, compte Xtream). Vous êtes seul responsable de leur légalité et de votre droit d\'y accéder.'),
    ('3. Usage interdit', 'Il est interdit d\'utiliser l\'application pour accéder à des contenus dont vous ne détenez pas les droits.'),
    ('4. Garantie', 'L\'application est fournie « en l\'état », sans garantie de disponibilité ni de compatibilité avec tous les serveurs.'),
    ('5. Responsabilité', 'L\'éditeur décline toute responsabilité quant aux contenus lus via l\'application.'),
  ];

  static const _about = [
    ('Player Flow $kVersion', 'Lecteur IPTV moderne pour Android : liste par catégories, favoris, recherche, lecture plein écran.'),
    ('Aucun contenu fourni', 'L\'application ne fournit aucun contenu ni abonnement : l\'utilisateur ajoute ses propres sources légales.'),
  ];

  @override
  Widget build(BuildContext context) {
    final title = kind == LegalKind.privacy
        ? 'Politique de confidentialité'
        : (kind == LegalKind.terms ? 'Conditions d\'utilisation' : 'À propos');
    final sections = kind == LegalKind.privacy ? _privacy : (kind == LegalKind.terms ? _terms : _about);
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: ListView(padding: const EdgeInsets.fromLTRB(20, 8, 20, 32), children: [
        for (final s in sections)
          Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(16),
            decoration: cardDeco(),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(s.$1, style: const TextStyle(fontWeight: FontWeight.w700, color: kAccent)),
              const SizedBox(height: 6),
              Text(s.$2, style: const TextStyle(height: 1.5)),
            ]),
          ),
      ]),
    );
  }
}
