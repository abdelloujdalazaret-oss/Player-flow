import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'home_page.dart';
import 'models.dart';
import 'theme.dart';

/// Ajout d'un abonnement : lien M3U ou Xtream Codes, avec test de connexion.
class AddSubPage extends StatefulWidget {
  const AddSubPage({super.key, this.first = false});
  final bool first;
  @override
  State<AddSubPage> createState() => _AddSubPageState();
}

class _AddSubPageState extends State<AddSubPage> {
  int mode = 0;
  final name = TextEditingController();
  final url = TextEditingController();
  final server = TextEditingController();
  final user = TextEditingController();
  final pass = TextEditingController();
  bool busy = false, failed = false, showPass = false;
  String? msg;

  @override
  void dispose() {
    for (final c in [name, url, server, user, pass]) {
      c.dispose();
    }
    super.dispose();
  }

  String _build() {
    if (mode == 0) return url.text.trim();
    var s = server.text.trim();
    if (!s.startsWith('http')) s = 'http://$s';
    while (s.endsWith('/')) {
      s = s.substring(0, s.length - 1);
    }
    final u = Uri.encodeComponent(user.text.trim());
    final p = Uri.encodeComponent(pass.text.trim());
    return '$s/get.php?username=$u&password=$p&type=m3u_plus&output=ts';
  }

  Future<void> _paste(TextEditingController c) async {
    final d = await Clipboard.getData('text/plain');
    if (d?.text != null) setState(() => c.text = d!.text!.trim());
  }

  Future<bool> _test(String u) async {
    try {
      final r = await http.get(Uri.parse(u), headers: {'User-Agent': kUA}).timeout(const Duration(seconds: 40));
      return r.statusCode < 400 && r.body.contains('://');
    } catch (_) {
      return false;
    }
  }

  Future<void> _save({bool force = false}) async {
    final u = _build();
    final bad = mode == 0
        ? !u.startsWith('http')
        : (server.text.trim().isEmpty || user.text.trim().isEmpty || pass.text.trim().isEmpty);
    if (bad) {
      setState(() => msg = 'Veuillez remplir les champs correctement.');
      return;
    }
    setState(() {
      busy = true;
      msg = null;
    });
    if (!force && !await _test(u)) {
      if (!mounted) return;
      setState(() {
        busy = false;
        failed = true;
        msg = 'Connexion échouée. $kHint';
      });
      return;
    }
    final subs = await Store.subs();
    final nm = name.text.trim().isEmpty ? (Uri.tryParse(u)?.host ?? 'Abonnement') : name.text.trim();
    subs.add(Sub(nm, u));
    await Store.saveSubs(subs);
    await Store.setActive(subs.length - 1);
    if (!mounted) return;
    Navigator.pushAndRemoveUntil(context, MaterialPageRoute<void>(builder: (_) => const HomePage()), (r) => false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Ajouter un abonnement'),
        automaticallyImplyLeading: !widget.first,
      ),
      body: ListView(padding: const EdgeInsets.fromLTRB(20, 8, 20, 32), children: [
        if (widget.first) ...[
          Center(
            child: ClipOval(
              child: Image.asset('assets/intro_logo.png', width: 96, height: 96,
                  errorBuilder: (_, __, ___) => const Icon(Icons.live_tv, size: 64, color: kAccent)),
            ),
          ),
          const SizedBox(height: 12),
          const Text('Bienvenue sur Player Flow',
              textAlign: TextAlign.center, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
          const SizedBox(height: 4),
          const Text('Ajoutez votre première source pour commencer.',
              textAlign: TextAlign.center, style: TextStyle(color: Colors.white54)),
          const SizedBox(height: 20),
        ],
        SegmentedButton<int>(
          segments: const [
            ButtonSegment(value: 0, label: Text('Lien M3U'), icon: Icon(Icons.link)),
            ButtonSegment(value: 1, label: Text('Xtream Codes'), icon: Icon(Icons.dns_outlined)),
          ],
          selected: {mode},
          onSelectionChanged: (s) => setState(() {
            mode = s.first;
            msg = null;
            failed = false;
          }),
        ),
        const SizedBox(height: 18),
        TextField(controller: name, decoration: const InputDecoration(labelText: 'Nom (facultatif)')),
        const SizedBox(height: 12),
        if (mode == 0)
          TextField(
            controller: url,
            keyboardType: TextInputType.url,
            decoration: InputDecoration(
              labelText: 'Lien M3U',
              suffixIcon: TextButton(onPressed: () => _paste(url), child: const Text('Coller')),
            ),
          )
        else ...[
          TextField(
            controller: server,
            keyboardType: TextInputType.url,
            decoration: InputDecoration(
              labelText: 'Serveur (ex : http://exemple.com:8080)',
              suffixIcon: TextButton(onPressed: () => _paste(server), child: const Text('Coller')),
            ),
          ),
          const SizedBox(height: 12),
          TextField(controller: user, decoration: const InputDecoration(labelText: 'Identifiant')),
          const SizedBox(height: 12),
          TextField(
            controller: pass,
            obscureText: !showPass,
            decoration: InputDecoration(
              labelText: 'Mot de passe',
              suffixIcon: IconButton(
                icon: Icon(showPass ? Icons.visibility_off : Icons.visibility),
                onPressed: () => setState(() => showPass = !showPass),
              ),
            ),
          ),
        ],
        const SizedBox(height: 16),
        if (msg != null)
          Container(
            padding: const EdgeInsets.all(12),
            margin: const EdgeInsets.only(bottom: 12),
            decoration: BoxDecoration(color: Colors.redAccent.withAlpha(40), borderRadius: BorderRadius.circular(14)),
            child: Text(msg!),
          ),
        FilledButton(
          onPressed: busy ? null : () => _save(),
          child: busy
              ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2))
              : const Text('Tester et enregistrer'),
        ),
        if (failed) ...[
          const SizedBox(height: 10),
          OutlinedButton(onPressed: busy ? null : () => _save(force: true), child: const Text('Enregistrer quand même')),
        ],
        const SizedBox(height: 20),
        const Text(
          'Player Flow ne fournit aucun contenu ni abonnement. Ajoutez uniquement vos propres sources légales.',
          textAlign: TextAlign.center,
          style: TextStyle(color: Colors.white38, fontSize: 12),
        ),
      ]),
    );
  }
}
