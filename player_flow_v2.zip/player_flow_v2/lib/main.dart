import 'package:flutter/material.dart';
import 'intro_page.dart';
import 'theme.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const PlayerFlowApp());
}

class PlayerFlowApp extends StatelessWidget {
  const PlayerFlowApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: kAppName,
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      themeMode: ThemeMode.dark,
      home: const IntroPage(),
    );
  }
}
