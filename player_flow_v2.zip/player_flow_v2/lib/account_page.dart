import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'legal_page.dart';
import 'models.dart';
import 'theme.dart';

/// Onglet « Compte » : abonnements, assistance, mentions légales, version.
class AccountPage extends StatelessWidget {
  const AccountPage({
    super.key,
    required this.subs,
    required this.active,
    required this.onSelect,
    required this.onDelete,
    required this.onAdd,
  });
  final List<Sub> subs;
  final int active;
  final void Function(int) onSelect;
  final void Function(int) onDelete;
  final VoidCallback onAdd;

  Future<void> _confirmDelete(BuildContext context, int i) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Supprimer l\'abonnement ?'),
        content: Text('« ${subs[i].name} » sera supprimé de cet appareil.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Supprimer')),
        ],
      ),
    );
    if (ok == true) onDelete(i);
  }

  Future<void> _launch(BuildContext context, String url) async {
    var ok = false;
    try {
      ok = await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    } catch (_) {
      ok = false;
    }
    if (!ok && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Impossible d\'ouvrir ce lien.')));
    }
  }

  Future<void> _support(BuildContext context) async {
    final s = await Store.support();
    if (!context.mounted) return;
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: kField,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Text('Assistance', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            if (s[0].isEmpty && s[1].isEmpty)
              const Padding(
                padding: EdgeInsets.all(12),
                child: Text('Aucun contact configuré pour le moment.', textAlign: TextAlign.center),
              ),
            if (s[0].isNotEmpty)
              ListTile(
                leading: const Icon(Icons.email_outlined, color: kAccent),
                title: const Text('Écrire par e-mail'),
                subtitle: Text(s[0]),
                onTap: () => _launch(context, 'mailto:${s[0]}'),
              ),
            if (s[1].isNotEmpty)
              ListTile(
                leading: const Icon(Icons.chat_outlined, color: kAccent),
                title: const Text('Discuter sur WhatsApp'),
                subtitle: Text(s[1]),
                onTap: () => _launch(context, 'https://wa.me/${s[1].replaceAll(RegExp(r'[^0-9]'), '')}'),
              ),
            ListTile(
              leading: const Icon(Icons.edit_outlined),
              title: const Text('Modifier les contacts'),
              onTap: () {
                Navigator.pop(ctx);
                showDialog<void>(context: context, builder: (_) => _ContactDialog(email: s[0], wa: s[1]));
              },
            ),
          ]),
        ),
      ),
    );
  }

  void _legal(BuildContext context, LegalKind k) {
    Navigator.push(context, MaterialPageRoute<void>(builder: (_) => LegalPage(kind: k)));
  }

  Widget _title(String t) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 20, 4, 8),
        child: Text(t.toUpperCase(), style: const TextStyle(color: kAccent, fontSize: 12, letterSpacing: 1.2, fontWeight: FontWeight.w700)),
      );

  Widget _item(IconData icon, String title, VoidCallback? onTap, {String? sub}) => Container(
        margin: const EdgeInsets.only(bottom: 8),
        decoration: cardDeco(),
        child: ListTile(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          leading: Icon(icon, color: Colors.white70),
          title: Text(title),
          subtitle: sub == null ? null : Text(sub),
          trailing: onTap == null ? null : const Icon(Icons.chevron_right, color: Colors.white38),
          onTap: onTap,
        ),
      );

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 24), children: [
      Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          gradient: const LinearGradient(colors: [Color(0xFF12304A), Color(0xFF182131)]),
          border: Border.all(color: Colors.white10),
        ),
        child: Row(children: [
          ClipOval(
            child: Image.asset('assets/intro_logo.png', width: 60, height: 60,
                errorBuilder: (_, __, ___) => const Icon(Icons.live_tv, size: 48, color: kAccent)),
          ),
          const SizedBox(width: 14),
          const Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(kAppName, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
              SizedBox(height: 2),
              Text('Votre lecteur IPTV', style: TextStyle(color: Colors.white60)),
            ]),
          ),
        ]),
      ),
      _title('Abonnements'),
      if (subs.isEmpty)
        const Padding(padding: EdgeInsets.all(12), child: Text('Aucun abonnement enregistré.', style: TextStyle(color: Colors.white60))),
      for (var i = 0; i < subs.length; i++)
        Container(
          margin: const EdgeInsets.only(bottom: 8),
          decoration: cardDeco(selected: i == active),
          child: ListTile(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            onTap: () => onSelect(i),
            leading: Icon(i == active ? Icons.check_circle : Icons.circle_outlined, color: i == active ? kAccent : Colors.white38),
            title: Text(subs[i].name, maxLines: 1, overflow: TextOverflow.ellipsis),
            subtitle: Text(i == active ? 'Actif' : 'Appuyez pour activer'),
            trailing: IconButton(
              icon: const Icon(Icons.delete_outline, color: Colors.white54),
              onPressed: () => _confirmDelete(context, i),
            ),
          ),
        ),
      const SizedBox(height: 4),
      OutlinedButton.icon(onPressed: onAdd, icon: const Icon(Icons.add), label: const Text('Ajouter un abonnement')),
      _title('Aide et informations'),
      _item(Icons.support_agent, 'Assistance', () => _support(context), sub: 'E-mail / WhatsApp'),
      _item(Icons.privacy_tip_outlined, 'Politique de confidentialité', () => _legal(context, LegalKind.privacy)),
      _item(Icons.description_outlined, 'Conditions d\'utilisation', () => _legal(context, LegalKind.terms)),
      _item(Icons.info_outline, 'À propos', () => _legal(context, LegalKind.about)),
      _item(Icons.tag, 'Version', null, sub: kVersion),
      const SizedBox(height: 8),
      const Text(
        'Player Flow ne fournit aucun contenu ni abonnement.',
        textAlign: TextAlign.center,
        style: TextStyle(color: Colors.white38, fontSize: 12),
      ),
    ]);
  }
}

class _ContactDialog extends StatefulWidget {
  const _ContactDialog({required this.email, required this.wa});
  final String email, wa;
  @override
  State<_ContactDialog> createState() => _ContactDialogState();
}

class _ContactDialogState extends State<_ContactDialog> {
  late final TextEditingController _e = TextEditingController(text: widget.email);
  late final TextEditingController _w = TextEditingController(text: widget.wa);

  @override
  void dispose() {
    _e.dispose();
    _w.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Contacts d\'assistance'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: _e, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'E-mail')),
        const SizedBox(height: 12),
        TextField(controller: _w, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'WhatsApp (avec indicatif)')),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Annuler')),
        FilledButton(
          onPressed: () async {
            await Store.saveSupport(_e.text.trim(), _w.text.trim());
            if (context.mounted) Navigator.pop(context);
          },
          child: const Text('Enregistrer'),
        ),
      ],
    );
  }
}
