import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';
import 'models.dart';
import 'theme.dart';

/// Lecteur plein écran. La vidéo est dans un Positioned.fill d'un Stack,
/// sans SafeArea ni AspectRatio : aucune bande noire ni petit rectangle.
class PlayerPage extends StatefulWidget {
  const PlayerPage({super.key, required this.list, required this.index});
  final List<Ch> list;
  final int index;
  @override
  State<PlayerPage> createState() => _PlayerPageState();
}

class _PlayerPageState extends State<PlayerPage> {
  VideoPlayerController? _c;
  late int _i = widget.index;
  BoxFit _fit = BoxFit.cover; // cover = Remplir, contain = Ajuster
  bool _show = true, _loading = true;
  String? _err;
  int _retry = 0, _gen = 0;
  Timer? _hide, _retryTimer;

  @override
  void initState() {
    super.initState();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    SystemChrome.setPreferredOrientations([DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]);
    _open();
    _schedule();
  }

  Future<void> _open() async {
    final gen = ++_gen;
    final old = _c;
    if (mounted) {
      setState(() {
        _c = null;
        _err = null;
        _loading = true;
      });
    }
    old?.removeListener(_tick);
    await old?.dispose();
    if (!mounted || gen != _gen) return;
    final c = VideoPlayerController.networkUrl(Uri.parse(widget.list[_i].url), httpHeaders: const {'User-Agent': kUA});
    try {
      await c.initialize();
      if (!mounted || gen != _gen) {
        await c.dispose();
        return;
      }
      c.addListener(_tick);
      setState(() {
        _c = c;
        _loading = false;
      });
      await c.play();
      _retry = 0;
    } catch (_) {
      await c.dispose();
      if (mounted && gen == _gen) _fail();
    }
  }

  void _tick() {
    final c = _c;
    if (c == null) return;
    if (c.value.hasError) {
      c.removeListener(_tick);
      _fail();
      return;
    }
    if (mounted) setState(() {});
  }

  void _fail() {
    if (!mounted) return;
    if (_retry < 3) {
      _retry++;
      setState(() => _loading = true);
      _retryTimer?.cancel();
      _retryTimer = Timer(Duration(seconds: 1 << _retry), _open); // 2 s, 4 s, 8 s
    } else {
      setState(() {
        _loading = false;
        _err = 'Impossible de lire ce flux.\n$kHint';
      });
    }
  }

  void _go(int d) {
    final n = widget.list.length;
    if (n < 2) return;
    _retryTimer?.cancel();
    _retry = 0;
    setState(() => _i = (_i + d + n) % n);
    _open();
    _schedule();
  }

  void _schedule() {
    _hide?.cancel();
    _hide = Timer(const Duration(seconds: 3), () {
      if (mounted) setState(() => _show = false);
    });
  }

  @override
  void dispose() {
    _gen++;
    _hide?.cancel();
    _retryTimer?.cancel();
    _c?.removeListener(_tick);
    _c?.dispose();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    SystemChrome.setPreferredOrientations(DeviceOrientation.values);
    super.dispose();
  }

  Widget _bar(bool top, Widget child) => IgnorePointer(
        ignoring: !_show,
        child: AnimatedOpacity(
          opacity: _show ? 1 : 0,
          duration: const Duration(milliseconds: 200),
          child: DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: top ? Alignment.topCenter : Alignment.bottomCenter,
                end: top ? Alignment.bottomCenter : Alignment.topCenter,
                colors: const [Colors.black87, Colors.transparent],
              ),
            ),
            child: child,
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final c = _c;
    final ready = c != null && c.value.isInitialized && c.value.size.width > 0;
    final playing = c != null && c.value.isPlaying;
    final buffering = c != null && c.value.isBuffering;
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(fit: StackFit.expand, children: [
        if (ready)
          Positioned.fill(
            child: FittedBox(
              fit: _fit,
              clipBehavior: Clip.hardEdge,
              child: SizedBox(width: c.value.size.width, height: c.value.size.height, child: VideoPlayer(c)),
            ),
          ),
        Positioned.fill(
          child: GestureDetector(
            behavior: HitTestBehavior.translucent,
            onTap: () {
              setState(() => _show = !_show);
              if (_show) _schedule();
            },
          ),
        ),
        if (_loading || buffering) const Center(child: CircularProgressIndicator(color: kAccent)),
        if (_err != null)
          Positioned.fill(
            child: Container(
              color: Colors.black87,
              alignment: Alignment.center,
              padding: const EdgeInsets.all(24),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                const Icon(Icons.error_outline, size: 48, color: Colors.redAccent),
                const SizedBox(height: 12),
                Text(_err!, textAlign: TextAlign.center),
                const SizedBox(height: 16),
                FilledButton.icon(
                  onPressed: () {
                    _retry = 0;
                    _open();
                  },
                  icon: const Icon(Icons.refresh),
                  label: const Text('Réessayer'),
                ),
              ]),
            ),
          ),
        Positioned(
          top: 0,
          left: 0,
          right: 0,
          child: _bar(
            true,
            SafeArea(
              bottom: false,
              child: Row(children: [
                IconButton(icon: const Icon(Icons.arrow_back), onPressed: () => Navigator.of(context).maybePop()),
                Expanded(
                  child: Text(widget.list[_i].name,
                      maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                ),
                IconButton(icon: const Icon(Icons.skip_previous), onPressed: () => _go(-1)),
                IconButton(icon: const Icon(Icons.skip_next), onPressed: () => _go(1)),
                TextButton.icon(
                  onPressed: () {
                    setState(() => _fit = _fit == BoxFit.cover ? BoxFit.contain : BoxFit.cover);
                    _schedule();
                  },
                  icon: Icon(_fit == BoxFit.cover ? Icons.fit_screen : Icons.fullscreen),
                  label: Text(_fit == BoxFit.cover ? 'Ajuster' : 'Remplir'),
                ),
              ]),
            ),
          ),
        ),
        Positioned(
          bottom: 0,
          left: 0,
          right: 0,
          child: _bar(
            false,
            SafeArea(
              top: false,
              child: Center(
                child: IconButton(
                  iconSize: 48,
                  icon: Icon(playing ? Icons.pause_circle : Icons.play_circle),
                  onPressed: () {
                    final v = _c;
                    if (v == null) return;
                    if (v.value.isPlaying) {
                      v.pause();
                    } else {
                      v.play();
                    }
                    _schedule();
                  },
                ),
              ),
            ),
          ),
        ),
      ]),
    );
  }
}
